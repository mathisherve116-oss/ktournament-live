export type Role =
  | "admin"
  | "club_manager"
  | "tournament_manager"
  | "score_volunteer"
  | "screen_manager"
  | "public";

// Matrice de permissions issue du cahier des charges (page 047-052).
// "*" = toutes les actions du domaine, sinon liste blanche d'actions.
export const PERMISSIONS: Record<Role, Record<string, string[] | "*">> = {
  admin: {
    clubs: "*",
    tournaments: "*",
    categories: "*",
    fields: "*",
    teams: "*",
    groups: "*",
    matches: "*",
    scores: "*",
    rankings: "*",
    screens: "*",
    remote: "*",
    sponsors: "*",
    finals: "*",
    users: "*",
  },
  club_manager: {
    clubs: ["read", "update"],
    tournaments: "*",
    categories: "*",
    fields: "*",
    teams: "*",
    groups: "*",
    matches: "*",
    scores: "*",
    rankings: "*",
    screens: "*",
    remote: "*",
    sponsors: "*",
    finals: "*",
  },
  tournament_manager: {
    tournaments: ["read", "update", "start", "finish"],
    categories: "*",
    fields: "*",
    teams: "*",
    groups: "*",
    matches: "*",
    scores: "*",
    rankings: "*",
    screens: "*",
    remote: "*",
    sponsors: "*",
    finals: "*",
  },
  score_volunteer: {
    tournaments: ["read"],
    matches: ["read", "start", "pause", "resume", "finish"],
    scores: ["create", "update", "validate"],
    rankings: ["read"],
  },
  screen_manager: {
    tournaments: ["read"],
    screens: ["read", "connect", "disconnect", "project"],
    remote: "*",
    sponsors: ["read"],
  },
  public: {
    tournaments: ["read_public"],
  },
};

export function can(role: Role, domain: string, action: string): boolean {
  const domainPerms = PERMISSIONS[role]?.[domain];
  if (!domainPerms) return false;
  if (domainPerms === "*") return true;
  return domainPerms.includes(action);
}
