"use client";
import { useEffect, useRef } from "react";
import { io, Socket } from "socket.io-client";

let sharedSocket: Socket | null = null;
function getSocket() {
  if (!sharedSocket) {
    sharedSocket = io({ path: "/socket.io", autoConnect: true });
  }
  return sharedSocket;
}

export function useRealtimeRoom(room: string | null | undefined, handlers: Record<string, (payload: unknown) => void>) {
  const handlersRef = useRef(handlers);
  handlersRef.current = handlers;

  useEffect(() => {
    if (!room) return;
    const socket = getSocket();
    socket.emit("join", room);

    const bound: Record<string, (payload: unknown) => void> = {};
    Object.keys(handlersRef.current).forEach((event) => {
      const fn = (payload: unknown) => handlersRef.current[event]?.(payload);
      bound[event] = fn;
      socket.on(event, fn);
    });

    return () => {
      Object.keys(bound).forEach((event) => socket.off(event, bound[event]));
      socket.emit("leave", room);
    };
  }, [room]);
}
