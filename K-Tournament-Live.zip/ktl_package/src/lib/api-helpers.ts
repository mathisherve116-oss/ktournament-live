import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "./auth";
import { can, Role } from "./rbac";

export function ok(data: unknown, status = 200) {
  return NextResponse.json({ data, errors: [] }, { status });
}
export function fail(message: string, status = 400) {
  return NextResponse.json({ data: null, errors: [{ message }] }, { status });
}

export async function requireUser(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return { user: null, response: fail("Non authentifie", 401) };
  return { user, response: null };
}

export async function requirePermission(req: NextRequest, domain: string, action: string) {
  const { user, response } = await requireUser(req);
  if (!user) return { user: null, response };
  if (!can(user.role as Role, domain, action)) {
    return { user: null, response: fail("Permissions insuffisantes", 403) };
  }
  return { user, response: null };
}
