import { randomUUID } from "node:crypto";
import { db, nowIso } from "./db";

function run(sql: string, ...params: unknown[]) {
  return db.prepare(sql).run(...(params as never[]));
}
function get<T>(sql: string, ...params: unknown[]): T | undefined {
  return db.prepare(sql).get(...(params as never[])) as T | undefined;
}
function all<T>(sql: string, ...params: unknown[]): T[] {
  return db.prepare(sql).all(...(params as never[])) as T[];
}

export const uid = () => randomUUID();

/* ---------------------------- Clubs & Users ---------------------------- */

export interface ClubRow {
  id: string; name: string; slug: string; logoUrl: string | null; city: string | null;
  country: string | null; contactEmail: string | null; status: string; createdAt: string; updatedAt: string;
}
export function createClub(data: { name: string; slug: string; city?: string; country?: string; contactEmail?: string }): ClubRow {
  const id = uid();
  const ts = nowIso();
  run(
    `INSERT INTO clubs (id,name,slug,city,country,contact_email,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`,
    id, data.name, data.slug, data.city || null, data.country || null, data.contactEmail || null, "active", ts, ts
  );
  return getClubById(id)!;
}
export function getClubById(id: string) {
  return get<ClubRow>(
    `SELECT id, name, slug, logo_url AS logoUrl, city, country, contact_email AS contactEmail, status, created_at AS createdAt, updated_at AS updatedAt FROM clubs WHERE id = ?`,
    id
  );
}

export interface UserRow {
  id: string; clubId: string | null; firstName: string; lastName: string; email: string;
  passwordHash: string; role: string; status: string; createdAt: string; updatedAt: string; lastLoginAt: string | null;
}
const USER_COLS = `id, club_id AS clubId, first_name AS firstName, last_name AS lastName, email, password_hash AS passwordHash, role, status, created_at AS createdAt, updated_at AS updatedAt, last_login_at AS lastLoginAt`;

export function createUser(data: { clubId?: string | null; firstName: string; lastName: string; email: string; passwordHash: string; role: string }): UserRow {
  const id = uid();
  const ts = nowIso();
  run(
    `INSERT INTO users (id,club_id,first_name,last_name,email,password_hash,role,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`,
    id, data.clubId || null, data.firstName, data.lastName, data.email.toLowerCase(), data.passwordHash, data.role, "active", ts, ts
  );
  return getUserById(id)!;
}
export function getUserByEmail(email: string) {
  return get<UserRow>(`SELECT ${USER_COLS} FROM users WHERE email = ?`, email.toLowerCase());
}
export function getUserById(id: string) {
  return get<UserRow>(`SELECT ${USER_COLS} FROM users WHERE id = ?`, id);
}
export function touchLogin(id: string) {
  run(`UPDATE users SET last_login_at = ? WHERE id = ?`, nowIso(), id);
}
export function listUsers() {
  return all<UserRow>(`SELECT ${USER_COLS} FROM users ORDER BY created_at ASC`);
}

/* ------------------------------ Audit log ------------------------------- */

export function logAudit(p: { userId?: string | null; action: string; entityType: string; entityId?: string | null; oldValue?: unknown; newValue?: unknown }) {
  run(
    `INSERT INTO audit_logs (id,user_id,action,entity_type,entity_id,old_value,new_value,created_at) VALUES (?,?,?,?,?,?,?,?)`,
    uid(), p.userId || null, p.action, p.entityType, p.entityId || null,
    p.oldValue ? JSON.stringify(p.oldValue) : null, p.newValue ? JSON.stringify(p.newValue) : null, nowIso()
  );
}
export function listAuditLogs(limit = 100) {
  return all(`SELECT id, user_id AS userId, action, entity_type AS entityType, entity_id AS entityId, old_value AS oldValue, new_value AS newValue, created_at AS createdAt FROM audit_logs ORDER BY created_at DESC LIMIT ?`, limit);
}

/* ------------------------------ Tournaments ------------------------------ */

export interface TournamentRow {
  id: string; clubId: string; name: string; startDate: string; endDate: string; location: string | null;
  city: string | null; mainCategory: string | null; coverImageUrl: string | null; status: string;
  createdAt: string; updatedAt: string;
}
const TOURNAMENT_COLS = `id, club_id AS clubId, name, start_date AS startDate, end_date AS endDate, location, city, main_category AS mainCategory, cover_image_url AS coverImageUrl, status, created_at AS createdAt, updated_at AS updatedAt`;

export function listTournaments() {
  return all<TournamentRow>(`SELECT ${TOURNAMENT_COLS} FROM tournaments ORDER BY start_date DESC`);
}
export function getTournament(id: string) {
  return get<TournamentRow>(`SELECT ${TOURNAMENT_COLS} FROM tournaments WHERE id = ?`, id);
}
export function createTournament(data: { clubId: string; name: string; startDate: string; endDate: string; location?: string; city?: string; mainCategory?: string; coverImageUrl?: string }) {
  const id = uid();
  const ts = nowIso();
  run(
    `INSERT INTO tournaments (id,club_id,name,start_date,end_date,location,city,main_category,cover_image_url,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    id, data.clubId, data.name, data.startDate, data.endDate, data.location || null, data.city || null, data.mainCategory || null, data.coverImageUrl || null, "draft", ts, ts
  );
  run(
    `INSERT INTO tournament_settings (id,tournament_id,match_duration,win_points,draw_points,loss_points,tie_break_rules,teams_qualified,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`,
    uid(), id, 15, 3, 1, 0, '["points","goal_diff","goals_for","head_to_head","fair_play","draw"]', 2, ts, ts
  );
  const slug = slugify(data.name) + "-" + id.slice(0, 6);
  run(`INSERT INTO public_links (id,tournament_id,slug,status,created_at,updated_at) VALUES (?,?,?,?,?,?)`, uid(), id, slug, "active", ts, ts);
  return getTournament(id)!;
}
export function updateTournament(id: string, data: Partial<{ name: string; startDate: string; endDate: string; location: string; city: string; mainCategory: string; coverImageUrl: string; status: string }>) {
  const current = getTournament(id);
  if (!current) return null;
  const merged = { ...current, ...data };
  run(
    `UPDATE tournaments SET name=?, start_date=?, end_date=?, location=?, city=?, main_category=?, cover_image_url=?, status=?, updated_at=? WHERE id=?`,
    merged.name, merged.startDate, merged.endDate, merged.location, merged.city, merged.mainCategory, merged.coverImageUrl, merged.status, nowIso(), id
  );
  return getTournament(id);
}
export function deleteTournament(id: string) {
  run(`DELETE FROM tournaments WHERE id = ?`, id);
}
export function slugify(s: string) {
  return s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export function getTournamentSettings(tournamentId: string) {
  const row = get<{ id: string; tournamentId: string; matchDuration: number; winPoints: number; drawPoints: number; lossPoints: number; tieBreakRules: string; teamsQualified: number }>(
    `SELECT id, tournament_id AS tournamentId, match_duration AS matchDuration, win_points AS winPoints, draw_points AS drawPoints, loss_points AS lossPoints, tie_break_rules AS tieBreakRules, teams_qualified AS teamsQualified FROM tournament_settings WHERE tournament_id = ?`,
    tournamentId
  );
  if (!row) return null;
  return { ...row, tieBreakRules: JSON.parse(row.tieBreakRules) as string[] };
}
export function updateTournamentSettings(tournamentId: string, data: Partial<{ matchDuration: number; winPoints: number; drawPoints: number; lossPoints: number; tieBreakRules: string[]; teamsQualified: number }>) {
  const current = getTournamentSettings(tournamentId);
  if (!current) return null;
  const merged = { ...current, ...data };
  run(
    `UPDATE tournament_settings SET match_duration=?, win_points=?, draw_points=?, loss_points=?, tie_break_rules=?, teams_qualified=?, updated_at=? WHERE tournament_id=?`,
    merged.matchDuration, merged.winPoints, merged.drawPoints, merged.lossPoints, JSON.stringify(merged.tieBreakRules), merged.teamsQualified, nowIso(), tournamentId
  );
  return getTournamentSettings(tournamentId);
}

export function getPublicLinkByTournament(tournamentId: string) {
  return get<{ id: string; tournamentId: string; slug: string; status: string }>(
    `SELECT id, tournament_id AS tournamentId, slug, status FROM public_links WHERE tournament_id = ?`,
    tournamentId
  );
}
export function getTournamentBySlug(slug: string) {
  const link = get<{ tournamentId: string; status: string }>(`SELECT tournament_id AS tournamentId, status FROM public_links WHERE slug = ?`, slug);
  if (!link || link.status !== "active") return null;
  return getTournament(link.tournamentId);
}
export function togglePublicLink(tournamentId: string, status: "active" | "disabled") {
  run(`UPDATE public_links SET status=?, updated_at=? WHERE tournament_id=?`, status, nowIso(), tournamentId);
  return getPublicLinkByTournament(tournamentId);
}

/* -------------------------------- Fields -------------------------------- */

export interface FieldRow { id: string; tournamentId: string; name: string; type: string; color: string; location: string | null; active: number; }
const FIELD_COLS = `id, tournament_id AS tournamentId, name, type, color, location, active`;
export function listFields(tournamentId: string) {
  return all<FieldRow>(`SELECT ${FIELD_COLS} FROM fields WHERE tournament_id = ? ORDER BY name ASC`, tournamentId);
}
export function createField(data: { tournamentId: string; name: string; type?: string; color?: string; location?: string }) {
  const id = uid();
  const ts = nowIso();
  run(`INSERT INTO fields (id,tournament_id,name,type,color,location,active,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`,
    id, data.tournamentId, data.name, data.type || "exterieur", data.color || "#00D97E", data.location || null, 1, ts, ts);
  return get<FieldRow>(`SELECT ${FIELD_COLS} FROM fields WHERE id = ?`, id)!;
}
export function updateField(id: string, data: Partial<{ name: string; type: string; color: string; location: string; active: boolean }>) {
  const current = get<FieldRow>(`SELECT ${FIELD_COLS} FROM fields WHERE id = ?`, id);
  if (!current) return null;
  const merged = { ...current, ...data, active: data.active !== undefined ? (data.active ? 1 : 0) : current.active };
  run(`UPDATE fields SET name=?, type=?, color=?, location=?, active=?, updated_at=? WHERE id=?`, merged.name, merged.type, merged.color, merged.location, merged.active, nowIso(), id);
  return get<FieldRow>(`SELECT ${FIELD_COLS} FROM fields WHERE id = ?`, id);
}
export function deleteField(id: string) {
  run(`DELETE FROM fields WHERE id = ?`, id);
}

/* ------------------------------ Categories ------------------------------ */

export interface CategoryRow { id: string; tournamentId: string; name: string; ageGroup: string | null; teamsCount: number; status: string; }
const CATEGORY_COLS = `id, tournament_id AS tournamentId, name, age_group AS ageGroup, teams_count AS teamsCount, status`;
export function listCategories(tournamentId: string) {
  return all<CategoryRow>(`SELECT ${CATEGORY_COLS} FROM categories WHERE tournament_id = ? ORDER BY name ASC`, tournamentId);
}
export function getCategory(id: string) {
  return get<CategoryRow>(`SELECT ${CATEGORY_COLS} FROM categories WHERE id = ?`, id);
}
export function createCategory(data: { tournamentId: string; name: string; ageGroup?: string }) {
  const id = uid();
  const ts = nowIso();
  run(`INSERT INTO categories (id,tournament_id,name,age_group,teams_count,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)`,
    id, data.tournamentId, data.name, data.ageGroup || null, 0, "draft", ts, ts);
  return getCategory(id)!;
}
export function updateCategory(id: string, data: Partial<{ name: string; ageGroup: string; status: string }>) {
  const current = getCategory(id);
  if (!current) return null;
  const merged = { ...current, ...data };
  run(`UPDATE categories SET name=?, age_group=?, status=?, updated_at=? WHERE id=?`, merged.name, merged.ageGroup, merged.status, nowIso(), id);
  return getCategory(id);
}
export function deleteCategory(id: string) {
  run(`DELETE FROM categories WHERE id = ?`, id);
}
export function refreshCategoryTeamsCount(categoryId: string) {
  const count = get<{ c: number }>(`SELECT COUNT(*) AS c FROM teams WHERE category_id = ?`, categoryId)!.c;
  run(`UPDATE categories SET teams_count=?, updated_at=? WHERE id=?`, count, nowIso(), categoryId);
}

/* ---------------------------------- Teams -------------------------------- */

export interface TeamRow { id: string; tournamentId: string; categoryId: string; name: string; clubName: string | null; logoUrl: string | null; managerName: string | null; status: string; }
const TEAM_COLS = `id, tournament_id AS tournamentId, category_id AS categoryId, name, club_name AS clubName, logo_url AS logoUrl, manager_name AS managerName, status`;
export function listTeams(tournamentId: string, categoryId?: string) {
  if (categoryId) return all<TeamRow>(`SELECT ${TEAM_COLS} FROM teams WHERE tournament_id = ? AND category_id = ? ORDER BY name ASC`, tournamentId, categoryId);
  return all<TeamRow>(`SELECT ${TEAM_COLS} FROM teams WHERE tournament_id = ? ORDER BY name ASC`, tournamentId);
}
export function getTeam(id: string) {
  return get<TeamRow>(`SELECT ${TEAM_COLS} FROM teams WHERE id = ?`, id);
}
export function createTeam(data: { tournamentId: string; categoryId: string; name: string; clubName?: string; managerName?: string }) {
  const id = uid();
  const ts = nowIso();
  run(`INSERT INTO teams (id,tournament_id,category_id,name,club_name,manager_name,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`,
    id, data.tournamentId, data.categoryId, data.name, data.clubName || null, data.managerName || null, "confirmed", ts, ts);
  refreshCategoryTeamsCount(data.categoryId);
  return getTeam(id)!;
}
export function updateTeam(id: string, data: Partial<{ name: string; clubName: string; managerName: string; status: string }>) {
  const current = getTeam(id);
  if (!current) return null;
  const merged = { ...current, ...data };
  run(`UPDATE teams SET name=?, club_name=?, manager_name=?, status=?, updated_at=? WHERE id=?`, merged.name, merged.clubName, merged.managerName, merged.status, nowIso(), id);
  return getTeam(id);
}
export function deleteTeam(id: string) {
  const t = getTeam(id);
  run(`DELETE FROM teams WHERE id = ?`, id);
  if (t) refreshCategoryTeamsCount(t.categoryId);
}

/* --------------------------------- Groups -------------------------------- */

export interface GroupRow { id: string; tournamentId: string; categoryId: string; name: string; format: string; status: string; }
const GROUP_COLS = `id, tournament_id AS tournamentId, category_id AS categoryId, name, format, status`;
export function listGroups(tournamentId: string, categoryId?: string) {
  if (categoryId) return all<GroupRow>(`SELECT ${GROUP_COLS} FROM groups_ WHERE tournament_id = ? AND category_id = ? ORDER BY name ASC`, tournamentId, categoryId);
  return all<GroupRow>(`SELECT ${GROUP_COLS} FROM groups_ WHERE tournament_id = ? ORDER BY name ASC`, tournamentId);
}
export function getGroup(id: string) {
  return get<GroupRow>(`SELECT ${GROUP_COLS} FROM groups_ WHERE id = ?`, id);
}
export function createGroup(data: { tournamentId: string; categoryId: string; name: string }) {
  const id = uid();
  const ts = nowIso();
  run(`INSERT INTO groups_ (id,tournament_id,category_id,name,format,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)`,
    id, data.tournamentId, data.categoryId, data.name, "poule", "draft", ts, ts);
  return getGroup(id)!;
}
export function deleteGroupsForCategory(categoryId: string) {
  const groups = all<{ id: string }>(`SELECT id FROM groups_ WHERE category_id = ?`, categoryId);
  for (const g of groups) {
    run(`DELETE FROM group_teams WHERE group_id = ?`, g.id);
  }
  run(`DELETE FROM groups_ WHERE category_id = ?`, categoryId);
}
export function addTeamToGroup(groupId: string, teamId: string, position: number) {
  run(`INSERT OR IGNORE INTO group_teams (id,group_id,team_id,position) VALUES (?,?,?,?)`, uid(), groupId, teamId, position);
}
export function listGroupTeams(groupId: string) {
  return all<{ teamId: string; position: number; name: string; clubName: string | null }>(
    `SELECT gt.team_id AS teamId, gt.position, t.name, t.club_name AS clubName FROM group_teams gt JOIN teams t ON t.id = gt.team_id WHERE gt.group_id = ? ORDER BY gt.position ASC`,
    groupId
  );
}
export function validateGroup(id: string) {
  run(`UPDATE groups_ SET status='validated', updated_at=? WHERE id=?`, nowIso(), id);
  return getGroup(id);
}

// Repartit les equipes d'une categorie en N poules equilibrees (serpentin).
export function autoGenerateGroups(categoryId: string, groupsCount: number) {
  const category = getCategory(categoryId)!;
  deleteGroupsForCategory(categoryId);
  const teams = listTeams(category.tournamentId, categoryId);
  const shuffled = [...teams].sort(() => Math.random() - 0.5);
  const groups: GroupRow[] = [];
  for (let i = 0; i < groupsCount; i++) {
    groups.push(createGroup({ tournamentId: category.tournamentId, categoryId, name: `Poule ${String.fromCharCode(65 + i)}` }));
  }
  shuffled.forEach((team, idx) => {
    const group = groups[idx % groupsCount];
    addTeamToGroup(group.id, team.id, Math.floor(idx / groupsCount));
  });
  return groups;
}

/* --------------------------------- Matches ------------------------------- */

export interface MatchRow {
  id: string; tournamentId: string; categoryId: string; groupId: string | null; fieldId: string | null;
  teamHomeId: string; teamAwayId: string; scheduledAt: string; duration: number; status: string; round: string | null;
}
const MATCH_COLS = `id, tournament_id AS tournamentId, category_id AS categoryId, group_id AS groupId, field_id AS fieldId, team_home_id AS teamHomeId, team_away_id AS teamAwayId, scheduled_at AS scheduledAt, duration, status, round`;

export interface MatchDetail extends MatchRow {
  teamHomeName: string; teamAwayName: string; fieldName: string | null; categoryName: string;
  homeScore: number | null; awayScore: number | null; scoreStatus: string | null;
}
const MATCH_DETAIL_SQL = `
  SELECT m.id, m.tournament_id AS tournamentId, m.category_id AS categoryId, m.group_id AS groupId, m.field_id AS fieldId,
    m.team_home_id AS teamHomeId, m.team_away_id AS teamAwayId, m.scheduled_at AS scheduledAt, m.duration, m.status, m.round,
    th.name AS teamHomeName, ta.name AS teamAwayName, f.name AS fieldName, c.name AS categoryName,
    s.home_score AS homeScore, s.away_score AS awayScore, s.status AS scoreStatus
  FROM matches m
  JOIN teams th ON th.id = m.team_home_id
  JOIN teams ta ON ta.id = m.team_away_id
  JOIN categories c ON c.id = m.category_id
  LEFT JOIN fields f ON f.id = m.field_id
  LEFT JOIN scores s ON s.match_id = m.id
`;

export function listMatches(tournamentId: string, filters: { categoryId?: string; groupId?: string; status?: string } = {}) {
  let sql = `${MATCH_DETAIL_SQL} WHERE m.tournament_id = ?`;
  const params: unknown[] = [tournamentId];
  if (filters.categoryId) { sql += ` AND m.category_id = ?`; params.push(filters.categoryId); }
  if (filters.groupId) { sql += ` AND m.group_id = ?`; params.push(filters.groupId); }
  if (filters.status) { sql += ` AND m.status = ?`; params.push(filters.status); }
  sql += ` ORDER BY m.scheduled_at ASC`;
  return all<MatchDetail>(sql, ...params);
}
export function getMatch(id: string) {
  return get<MatchDetail>(`${MATCH_DETAIL_SQL} WHERE m.id = ?`, id);
}
export function createMatch(data: { tournamentId: string; categoryId: string; groupId?: string | null; fieldId?: string | null; teamHomeId: string; teamAwayId: string; scheduledAt: string; duration?: number; round?: string }) {
  const id = uid();
  const ts = nowIso();
  run(
    `INSERT INTO matches (id,tournament_id,category_id,group_id,field_id,team_home_id,team_away_id,scheduled_at,duration,status,round,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    id, data.tournamentId, data.categoryId, data.groupId || null, data.fieldId || null, data.teamHomeId, data.teamAwayId, data.scheduledAt, data.duration || 15, "scheduled", data.round || null, ts, ts
  );
  run(`INSERT INTO scores (id,match_id,home_score,away_score,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)`, uid(), id, 0, 0, "pending", ts, ts);
  return getMatch(id)!;
}
export function updateMatchStatus(id: string, status: string) {
  run(`UPDATE matches SET status=?, updated_at=? WHERE id=?`, status, nowIso(), id);
  return getMatch(id);
}
export function updateMatch(id: string, data: Partial<{ fieldId: string; scheduledAt: string; duration: number }>) {
  const current = getMatch(id);
  if (!current) return null;
  const merged = { ...current, ...data };
  run(`UPDATE matches SET field_id=?, scheduled_at=?, duration=?, updated_at=? WHERE id=?`, merged.fieldId, merged.scheduledAt, merged.duration, nowIso(), id);
  return getMatch(id);
}

// Generation round-robin simple des matchs pour toutes les poules d'une categorie.
export function generateMatchesForCategory(categoryId: string, opts: { startTime: string; slotMinutes: number; fieldIds: string[] }) {
  const category = getCategory(categoryId)!;
  const groups = listGroups(category.tournamentId, categoryId);
  const created: MatchDetail[] = [];
  let slotIndex = 0;
  const start = new Date(opts.startTime).getTime();

  for (const group of groups) {
    const teams = listGroupTeams(group.id);
    const ids = teams.map((t) => t.teamId);
    const pairs: [string, string][] = [];
    for (let i = 0; i < ids.length; i++) {
      for (let j = i + 1; j < ids.length; j++) pairs.push([ids[i], ids[j]]);
    }
    for (const [home, away] of pairs) {
      const field = opts.fieldIds.length ? opts.fieldIds[slotIndex % opts.fieldIds.length] : null;
      const scheduledAt = new Date(start + slotIndex * opts.slotMinutes * 60000).toISOString();
      const match = createMatch({ tournamentId: category.tournamentId, categoryId, groupId: group.id, fieldId: field, teamHomeId: home, teamAwayId: away, scheduledAt, duration: opts.slotMinutes });
      created.push(match);
      slotIndex++;
    }
  }
  return created;
}

/* ---------------------------------- Scores -------------------------------- */

export function getScoreByMatch(matchId: string) {
  return get<{ id: string; matchId: string; homeScore: number; awayScore: number; status: string }>(
    `SELECT id, match_id AS matchId, home_score AS homeScore, away_score AS awayScore, status FROM scores WHERE match_id = ?`,
    matchId
  );
}
export function submitScore(matchId: string, homeScore: number, awayScore: number, updatedBy?: string) {
  const ts = nowIso();
  run(`UPDATE scores SET home_score=?, away_score=?, status='pending', updated_at=? WHERE match_id=?`, homeScore, awayScore, ts, matchId);
  logAudit({ userId: updatedBy, action: "score.update", entityType: "score", entityId: matchId, newValue: { homeScore, awayScore } });
  return getScoreByMatch(matchId);
}
export function validateScore(matchId: string, validatedBy?: string) {
  const ts = nowIso();
  run(`UPDATE scores SET status='validated', validated_by=?, validated_at=?, updated_at=? WHERE match_id=?`, validatedBy || null, ts, ts, matchId);
  updateMatchStatus(matchId, "finished");
  logAudit({ userId: validatedBy, action: "score.validate", entityType: "score", entityId: matchId });
  return getScoreByMatch(matchId);
}
export function addMatchEvent(data: { matchId: string; teamId?: string; eventType: string; minute?: number; createdBy?: string }) {
  run(`INSERT INTO match_events (id,match_id,team_id,event_type,minute,created_by,created_at) VALUES (?,?,?,?,?,?,?)`,
    uid(), data.matchId, data.teamId || null, data.eventType, data.minute ?? null, data.createdBy || null, nowIso());
}
export function listMatchEvents(matchId: string) {
  return all(`SELECT id, team_id AS teamId, event_type AS eventType, minute, created_at AS createdAt FROM match_events WHERE match_id = ? ORDER BY created_at ASC`, matchId);
}

/* -------------------------------- Rankings -------------------------------- */

export interface RankingRow {
  id: string; tournamentId: string; categoryId: string; groupId: string; teamId: string; teamName: string; clubName: string | null;
  played: number; wins: number; draws: number; losses: number; gf: number; ga: number; diff: number; points: number; rank: number;
}
export function getGroupRankings(groupId: string) {
  return all<RankingRow>(
    `SELECT r.id, r.tournament_id AS tournamentId, r.category_id AS categoryId, r.group_id AS groupId, r.team_id AS teamId,
      t.name AS teamName, t.club_name AS clubName,
      r.played, r.wins, r.draws, r.losses, r.gf, r.ga, r.diff, r.points, r.rank
     FROM rankings r JOIN teams t ON t.id = r.team_id WHERE r.group_id = ? ORDER BY r.rank ASC`,
    groupId
  );
}

export function recalculateGroupRanking(groupId: string) {
  const group = getGroup(groupId);
  if (!group) throw new Error("Poule introuvable");
  const settings = getTournamentSettings(group.tournamentId)!;
  const groupTeams = listGroupTeams(groupId);
  const matches = listMatches(group.tournamentId, { groupId });

  type Stat = { teamId: string; played: number; wins: number; draws: number; losses: number; gf: number; ga: number };
  const stats = new Map<string, Stat>();
  for (const gt of groupTeams) stats.set(gt.teamId, { teamId: gt.teamId, played: 0, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0 });

  const headToHead = new Map<string, number>();

  for (const m of matches) {
    if (m.homeScore === null || m.awayScore === null || m.scoreStatus !== "validated") continue;
    const home = stats.get(m.teamHomeId);
    const away = stats.get(m.teamAwayId);
    if (!home || !away) continue;
    home.played++; away.played++;
    home.gf += m.homeScore; home.ga += m.awayScore;
    away.gf += m.awayScore; away.ga += m.homeScore;
    headToHead.set(`${m.teamHomeId}>${m.teamAwayId}`, m.homeScore - m.awayScore);
    headToHead.set(`${m.teamAwayId}>${m.teamHomeId}`, m.awayScore - m.homeScore);
    if (m.homeScore > m.awayScore) { home.wins++; away.losses++; }
    else if (m.homeScore < m.awayScore) { away.wins++; home.losses++; }
    else { home.draws++; away.draws++; }
  }

  const rows = Array.from(stats.values()).map((s) => ({
    ...s,
    diff: s.gf - s.ga,
    points: s.wins * settings.winPoints + s.draws * settings.drawPoints + s.losses * settings.lossPoints,
  }));

  rows.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.diff !== a.diff) return b.diff - a.diff;
    if (b.gf !== a.gf) return b.gf - a.gf;
    const h2h = headToHead.get(`${a.teamId}>${b.teamId}`);
    if (h2h) return -h2h;
    return 0;
  });

  const ts = nowIso();
  rows.forEach((row, idx) => {
    const existing = get<{ id: string }>(`SELECT id FROM rankings WHERE group_id=? AND team_id=?`, groupId, row.teamId);
    if (existing) {
      run(`UPDATE rankings SET played=?, wins=?, draws=?, losses=?, gf=?, ga=?, diff=?, points=?, rank=?, updated_at=? WHERE id=?`,
        row.played, row.wins, row.draws, row.losses, row.gf, row.ga, row.diff, row.points, idx + 1, ts, existing.id);
    } else {
      run(`INSERT INTO rankings (id,tournament_id,category_id,group_id,team_id,played,wins,draws,losses,gf,ga,diff,points,rank,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        uid(), group.tournamentId, group.categoryId, groupId, row.teamId, row.played, row.wins, row.draws, row.losses, row.gf, row.ga, row.diff, row.points, idx + 1, ts);
    }
  });

  return getGroupRankings(groupId);
}

/* --------------------------------- Screens -------------------------------- */

export interface ScreenRow { id: string; tournamentId: string; name: string; type: string; location: string | null; resolution: string | null; status: string; lastSeenAt: string | null; }
const SCREEN_COLS = `id, tournament_id AS tournamentId, name, type, location, resolution, status, last_seen_at AS lastSeenAt`;
export function listScreens(tournamentId: string) {
  return all<ScreenRow>(`SELECT ${SCREEN_COLS} FROM screens WHERE tournament_id = ? ORDER BY name ASC`, tournamentId);
}
export function getScreen(id: string) {
  return get<ScreenRow>(`SELECT ${SCREEN_COLS} FROM screens WHERE id = ?`, id);
}
export function createScreen(data: { tournamentId: string; name: string; type?: string; location?: string }) {
  const id = uid();
  const ts = nowIso();
  run(`INSERT INTO screens (id,tournament_id,name,type,location,resolution,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`,
    id, data.tournamentId, data.name, data.type || "tv", data.location || null, "1920x1080", "offline", ts, ts);
  run(`INSERT INTO screen_sessions (id,screen_id,active_content_type,current_payload,status,updated_at) VALUES (?,?,?,?,?,?)`,
    uid(), id, "home", "{}", "idle", ts);
  return getScreen(id)!;
}
export function setScreenStatus(id: string, status: "offline" | "online" | "projecting") {
  run(`UPDATE screens SET status=?, last_seen_at=?, updated_at=? WHERE id=?`, status, nowIso(), nowIso(), id);
  return getScreen(id);
}
export function getScreenSession(screenId: string) {
  const row = get<{ id: string; screenId: string; activeContentType: string; currentPayload: string; status: string; updatedAt: string }>(
    `SELECT id, screen_id AS screenId, active_content_type AS activeContentType, current_payload AS currentPayload, status, updated_at AS updatedAt FROM screen_sessions WHERE screen_id = ?`,
    screenId
  );
  if (!row) return null;
  return { ...row, currentPayload: JSON.parse(row.currentPayload) };
}
export function projectContent(screenId: string, contentType: string, payload: unknown, updatedBy?: string) {
  run(`UPDATE screen_sessions SET active_content_type=?, current_payload=?, status='projecting', updated_by=?, updated_at=? WHERE screen_id=?`,
    contentType, JSON.stringify(payload || {}), updatedBy || null, nowIso(), screenId);
  setScreenStatus(screenId, "projecting");
  return getScreenSession(screenId);
}
export function stopProjection(screenId: string) {
  run(`UPDATE screen_sessions SET status='idle', updated_at=? WHERE screen_id=?`, nowIso(), screenId);
  return getScreenSession(screenId);
}

/* -------------------------------- Sponsors -------------------------------- */

export interface SponsorRow { id: string; tournamentId: string; name: string; logoUrl: string | null; level: string; status: string; slogan: string | null; linkUrl: string | null; durationSeconds: number; orderNo: number; }
const SPONSOR_COLS = `id, tournament_id AS tournamentId, name, logo_url AS logoUrl, level, status, slogan, link_url AS linkUrl, duration_seconds AS durationSeconds, order_no AS orderNo`;
export function listSponsors(tournamentId: string) {
  return all<SponsorRow>(`SELECT ${SPONSOR_COLS} FROM sponsors WHERE tournament_id = ? ORDER BY order_no ASC, level ASC`, tournamentId);
}
export function createSponsor(data: { tournamentId: string; name: string; level?: string; slogan?: string; linkUrl?: string; durationSeconds?: number }) {
  const id = uid();
  const ts = nowIso();
  const maxOrder = get<{ m: number }>(`SELECT COALESCE(MAX(order_no),-1) AS m FROM sponsors WHERE tournament_id=?`, data.tournamentId)!.m;
  run(`INSERT INTO sponsors (id,tournament_id,name,level,status,slogan,link_url,duration_seconds,order_no,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    id, data.tournamentId, data.name, data.level || "partner", "active", data.slogan || null, data.linkUrl || null, data.durationSeconds || 8, maxOrder + 1, ts, ts);
  return get<SponsorRow>(`SELECT ${SPONSOR_COLS} FROM sponsors WHERE id=?`, id)!;
}
export function updateSponsor(id: string, data: Partial<{ name: string; level: string; status: string; slogan: string; linkUrl: string; durationSeconds: number; orderNo: number }>) {
  const current = get<SponsorRow>(`SELECT ${SPONSOR_COLS} FROM sponsors WHERE id=?`, id);
  if (!current) return null;
  const merged = { ...current, ...data };
  run(`UPDATE sponsors SET name=?, level=?, status=?, slogan=?, link_url=?, duration_seconds=?, order_no=?, updated_at=? WHERE id=?`,
    merged.name, merged.level, merged.status, merged.slogan, merged.linkUrl, merged.durationSeconds, merged.orderNo, nowIso(), id);
  return get<SponsorRow>(`SELECT ${SPONSOR_COLS} FROM sponsors WHERE id=?`, id);
}
export function deleteSponsor(id: string) {
  run(`DELETE FROM sponsors WHERE id = ?`, id);
}

/* ------------------------------ Final phases ------------------------------ */

export interface FinalPhaseRow { id: string; tournamentId: string; categoryId: string; round: string; matchId: string | null; position: number; status: string; }
const FINAL_COLS = `id, tournament_id AS tournamentId, category_id AS categoryId, round, match_id AS matchId, position, status`;
export function listFinalPhases(tournamentId: string, categoryId?: string) {
  if (categoryId) return all<FinalPhaseRow>(`SELECT ${FINAL_COLS} FROM final_phases WHERE tournament_id=? AND category_id=? ORDER BY round ASC, position ASC`, tournamentId, categoryId);
  return all<FinalPhaseRow>(`SELECT ${FINAL_COLS} FROM final_phases WHERE tournament_id=? ORDER BY round ASC, position ASC`, tournamentId);
}
export function generateFinalPhase(categoryId: string, round: string, qualifiedTeamIds: string[], opts: { startTime: string; slotMinutes: number; fieldId?: string }) {
  const category = getCategory(categoryId)!;
  const ts = nowIso();
  const created: FinalPhaseRow[] = [];
  for (let i = 0; i < qualifiedTeamIds.length; i += 2) {
    const home = qualifiedTeamIds[i];
    const away = qualifiedTeamIds[i + 1];
    if (!home || !away) continue;
    const scheduledAt = new Date(new Date(opts.startTime).getTime() + (i / 2) * opts.slotMinutes * 60000).toISOString();
    const match = createMatch({ tournamentId: category.tournamentId, categoryId, fieldId: opts.fieldId, teamHomeId: home, teamAwayId: away, scheduledAt, duration: opts.slotMinutes, round });
    const id = uid();
    run(`INSERT INTO final_phases (id,tournament_id,category_id,round,match_id,position,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`,
      id, category.tournamentId, categoryId, round, match.id, i / 2, "pending", ts, ts);
    created.push(get<FinalPhaseRow>(`SELECT ${FINAL_COLS} FROM final_phases WHERE id=?`, id)!);
  }
  return created;
}
