import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import fs from "node:fs";

const DB_PATH = process.env.DATABASE_FILE || path.join(process.cwd(), "data", "ktl.db");
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const globalForDb = globalThis as unknown as { __ktl_db?: DatabaseSync };

export const db: DatabaseSync = globalForDb.__ktl_db ?? new DatabaseSync(DB_PATH);
if (process.env.NODE_ENV !== "production") globalForDb.__ktl_db = db;

db.exec("PRAGMA journal_mode = WAL;");
db.exec("PRAGMA foreign_keys = ON;");

const SCHEMA = `
CREATE TABLE IF NOT EXISTS clubs (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
  logo_url TEXT, city TEXT, country TEXT, contact_email TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, club_id TEXT REFERENCES clubs(id),
  first_name TEXT NOT NULL, last_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
  role TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_login_at TEXT
);
CREATE TABLE IF NOT EXISTS tournaments (
  id TEXT PRIMARY KEY, club_id TEXT NOT NULL REFERENCES clubs(id),
  name TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL,
  location TEXT, city TEXT, main_category TEXT, cover_image_url TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tournament_settings (
  id TEXT PRIMARY KEY, tournament_id TEXT UNIQUE NOT NULL REFERENCES tournaments(id),
  match_duration INTEGER NOT NULL DEFAULT 15,
  win_points INTEGER NOT NULL DEFAULT 3,
  draw_points INTEGER NOT NULL DEFAULT 1,
  loss_points INTEGER NOT NULL DEFAULT 0,
  tie_break_rules TEXT NOT NULL DEFAULT '["points","goal_diff","goals_for","head_to_head","fair_play","draw"]',
  teams_qualified INTEGER NOT NULL DEFAULT 2,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS fields (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'exterieur', color TEXT NOT NULL DEFAULT '#00D97E',
  location TEXT, active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  name TEXT NOT NULL, age_group TEXT, teams_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS teams (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  category_id TEXT NOT NULL REFERENCES categories(id),
  name TEXT NOT NULL, club_name TEXT, logo_url TEXT, manager_name TEXT,
  status TEXT NOT NULL DEFAULT 'registered',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS groups_ (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  category_id TEXT NOT NULL REFERENCES categories(id),
  name TEXT NOT NULL, format TEXT NOT NULL DEFAULT 'poule', status TEXT NOT NULL DEFAULT 'draft',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS group_teams (
  id TEXT PRIMARY KEY, group_id TEXT NOT NULL REFERENCES groups_(id),
  team_id TEXT NOT NULL REFERENCES teams(id), position INTEGER NOT NULL DEFAULT 0,
  UNIQUE(group_id, team_id)
);
CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  category_id TEXT NOT NULL REFERENCES categories(id),
  group_id TEXT REFERENCES groups_(id), field_id TEXT REFERENCES fields(id),
  team_home_id TEXT NOT NULL REFERENCES teams(id), team_away_id TEXT NOT NULL REFERENCES teams(id),
  scheduled_at TEXT NOT NULL, duration INTEGER NOT NULL DEFAULT 15,
  status TEXT NOT NULL DEFAULT 'scheduled', round TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS match_events (
  id TEXT PRIMARY KEY, match_id TEXT NOT NULL REFERENCES matches(id),
  team_id TEXT, event_type TEXT NOT NULL, minute INTEGER, created_by TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS scores (
  id TEXT PRIMARY KEY, match_id TEXT UNIQUE NOT NULL REFERENCES matches(id),
  home_score INTEGER NOT NULL DEFAULT 0, away_score INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending', validated_by TEXT, validated_at TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS rankings (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  category_id TEXT NOT NULL REFERENCES categories(id), group_id TEXT NOT NULL REFERENCES groups_(id),
  team_id TEXT NOT NULL REFERENCES teams(id),
  played INTEGER NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0, draws INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0, gf INTEGER NOT NULL DEFAULT 0, ga INTEGER NOT NULL DEFAULT 0,
  diff INTEGER NOT NULL DEFAULT 0, points INTEGER NOT NULL DEFAULT 0, rank INTEGER NOT NULL DEFAULT 0,
  manual_override INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL,
  UNIQUE(group_id, team_id)
);
CREATE TABLE IF NOT EXISTS screens (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'tv', location TEXT,
  resolution TEXT DEFAULT '1920x1080', status TEXT NOT NULL DEFAULT 'offline', last_seen_at TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS screen_sessions (
  id TEXT PRIMARY KEY, screen_id TEXT UNIQUE NOT NULL REFERENCES screens(id),
  active_content_type TEXT NOT NULL DEFAULT 'home', current_payload TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'idle', updated_by TEXT, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS final_phases (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  category_id TEXT NOT NULL REFERENCES categories(id), round TEXT NOT NULL,
  match_id TEXT UNIQUE REFERENCES matches(id), position INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sponsors (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  name TEXT NOT NULL, logo_url TEXT, level TEXT NOT NULL DEFAULT 'partner',
  status TEXT NOT NULL DEFAULT 'active', slogan TEXT, link_url TEXT,
  duration_seconds INTEGER NOT NULL DEFAULT 8, order_no INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sponsor_rotations (
  id TEXT PRIMARY KEY, sponsor_id TEXT NOT NULL REFERENCES sponsors(id), screen_id TEXT,
  order_no INTEGER NOT NULL DEFAULT 0, duration_seconds INTEGER NOT NULL DEFAULT 8,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS screen_contents (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  content_type TEXT NOT NULL, title TEXT, payload TEXT NOT NULL DEFAULT '{}',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY, user_id TEXT, action TEXT NOT NULL, entity_type TEXT NOT NULL,
  entity_id TEXT, old_value TEXT, new_value TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS public_links (
  id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL REFERENCES tournaments(id),
  slug TEXT UNIQUE NOT NULL, qr_code_url TEXT, status TEXT NOT NULL DEFAULT 'active',
  expires_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_club ON users(club_id);
CREATE INDEX IF NOT EXISTS idx_tournaments_club ON tournaments(club_id);
CREATE INDEX IF NOT EXISTS idx_fields_tournament ON fields(tournament_id);
CREATE INDEX IF NOT EXISTS idx_categories_tournament ON categories(tournament_id);
CREATE INDEX IF NOT EXISTS idx_teams_category ON teams(category_id);
CREATE INDEX IF NOT EXISTS idx_groups_category ON groups_(category_id);
CREATE INDEX IF NOT EXISTS idx_matches_field ON matches(field_id);
CREATE INDEX IF NOT EXISTS idx_matches_group ON matches(group_id);
CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status);
CREATE INDEX IF NOT EXISTS idx_rankings_group ON rankings(group_id);
CREATE INDEX IF NOT EXISTS idx_screens_tournament ON screens(tournament_id);
CREATE INDEX IF NOT EXISTS idx_sponsors_tournament ON sponsors(tournament_id);
CREATE INDEX IF NOT EXISTS idx_public_links_slug ON public_links(slug);
`;

db.exec(SCHEMA);

export function nowIso() {
  return new Date().toISOString();
}
