type Emitter = { to: (room: string) => { emit: (event: string, payload: unknown) => void } };

export function emitToTournament(tournamentId: string, event: string, payload: unknown = {}) {
  const io = (global as unknown as { __ktl_io?: Emitter }).__ktl_io;
  if (!io) return;
  io.to(`tournament:${tournamentId}`).emit(event, { ...(payload as object), event, ts: Date.now() });
}
export function emitToScreen(screenId: string, event: string, payload: unknown = {}) {
  const io = (global as unknown as { __ktl_io?: Emitter }).__ktl_io;
  if (!io) return;
  io.to(`screen:${screenId}`).emit(event, { ...(payload as object), event, ts: Date.now() });
}
