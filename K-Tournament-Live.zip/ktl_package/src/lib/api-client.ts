export interface ApiResponse<T> {
  data: T | null;
  errors: { message: string }[];
}

export async function api<T = unknown>(path: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
  const res = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    credentials: "same-origin",
  });
  const json = (await res.json().catch(() => ({ data: null, errors: [{ message: "Reponse invalide du serveur" }] }))) as ApiResponse<T>;
  if (!res.ok && json.errors.length === 0) {
    json.errors = [{ message: `Erreur ${res.status}` }];
  }
  return json;
}

export const apiGet = <T = unknown>(path: string) => api<T>(path);
export const apiPost = <T = unknown>(path: string, body?: unknown) => api<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined });
export const apiPut = <T = unknown>(path: string, body?: unknown) => api<T>(path, { method: "PUT", body: body ? JSON.stringify(body) : undefined });
export const apiDelete = <T = unknown>(path: string) => api<T>(path, { method: "DELETE" });
