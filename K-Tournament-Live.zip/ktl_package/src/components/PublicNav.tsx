"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const TABS = [
  { slug: "", label: "Accueil" },
  { slug: "matches", label: "Matchs" },
  { slug: "rankings", label: "Classements" },
  { slug: "sponsors", label: "Sponsors" },
];

export function PublicNav({ slug }: { slug: string }) {
  const pathname = usePathname();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-20 border-t border-line bg-ink/95 backdrop-blur">
      <div className="mx-auto flex max-w-md">
        {TABS.map((t) => {
          const href = `/t/${slug}${t.slug ? `/${t.slug}` : ""}`;
          const active = pathname === href;
          return (
            <Link key={t.slug} href={href} className={`flex-1 py-3 text-center text-xs font-semibold ${active ? "text-accent" : "text-white/40"}`}>
              {t.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
