export function PublicUnavailable() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ink px-6 text-center text-white">
      <p className="text-lg font-bold">Ce tournoi n'est plus accessible</p>
      <p className="mt-2 text-sm text-white/50">Le lien est peut-etre desactive ou incorrect.</p>
    </div>
  );
}
