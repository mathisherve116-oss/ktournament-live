"use client";
import { ButtonHTMLAttributes, InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";

export function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`rounded-2xl border border-line bg-panel/80 p-5 shadow-lg shadow-black/20 ${className}`}>{children}</div>;
}

export function PageHeader({ eyebrow, title, subtitle, actions }: { eyebrow?: string; title: string; subtitle?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow && <div className="mb-1 text-xs font-semibold uppercase tracking-widest text-accent">{eyebrow}</div>}
        <h1 className="text-2xl font-bold text-white sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-white/60">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-shrink-0 gap-2">{actions}</div>}
    </div>
  );
}

export function Button({ variant = "primary", className = "", ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" | "danger" }) {
  const base = "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:opacity-40 disabled:cursor-not-allowed";
  const styles: Record<string, string> = {
    primary: "bg-accent text-ink hover:brightness-110",
    secondary: "bg-white/5 text-white border border-line hover:bg-white/10",
    ghost: "text-white/70 hover:text-white hover:bg-white/5",
    danger: "bg-danger/15 text-danger border border-danger/30 hover:bg-danger/25",
  };
  return <button className={`${base} ${styles[variant]} ${className}`} {...props} />;
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`w-full rounded-lg border border-line bg-black/30 px-3 py-2 text-sm text-white placeholder-white/30 outline-none focus:border-accent ${props.className || ""}`} />;
}

export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`w-full rounded-lg border border-line bg-black/30 px-3 py-2 text-sm text-white placeholder-white/30 outline-none focus:border-accent ${props.className || ""}`} />;
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`w-full rounded-lg border border-line bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-accent ${props.className || ""}`} />;
}

export function Label({ children }: { children: React.ReactNode }) {
  return <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-white/50">{children}</label>;
}

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label>{label}</Label>
      {children}
    </div>
  );
}

const BADGE_STYLES: Record<string, string> = {
  draft: "bg-white/10 text-white/70",
  scheduled: "bg-accent2/15 text-accent2",
  live: "bg-accent/15 text-accent",
  paused: "bg-warn/15 text-warn",
  finished: "bg-white/10 text-white/50",
  cancelled: "bg-danger/15 text-danger",
  active: "bg-accent/15 text-accent",
  inactive: "bg-white/10 text-white/50",
  validated: "bg-accent/15 text-accent",
  pending: "bg-warn/15 text-warn",
  online: "bg-accent/15 text-accent",
  offline: "bg-white/10 text-white/50",
  projecting: "bg-accent2/15 text-accent2",
  disabled: "bg-danger/15 text-danger",
};

export function Badge({ status, children }: { status?: string; children: React.ReactNode }) {
  const style = (status && BADGE_STYLES[status]) || "bg-white/10 text-white/70";
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${style}`}>{children}</span>;
}

export function EmptyState({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="rounded-xl border border-dashed border-line py-10 text-center">
      <p className="font-medium text-white/70">{title}</p>
      {subtitle && <p className="mt-1 text-sm text-white/40">{subtitle}</p>}
    </div>
  );
}

export function Spinner() {
  return <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/20 border-t-accent" />;
}
