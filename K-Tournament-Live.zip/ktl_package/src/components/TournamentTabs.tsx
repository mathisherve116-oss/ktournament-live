"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const TABS = [
  { slug: "summary", label: "Resume" },
  { slug: "settings", label: "Parametres" },
  { slug: "categories", label: "Categories" },
  { slug: "fields", label: "Terrains" },
  { slug: "teams", label: "Equipes" },
  { slug: "groups", label: "Poules" },
  { slug: "matches", label: "Matchs" },
  { slug: "scores", label: "Score live" },
  { slug: "rankings", label: "Classements" },
  { slug: "finals", label: "Phases finales" },
  { slug: "sponsors", label: "Sponsors" },
  { slug: "screens", label: "Ecrans" },
];

export function TournamentTabs({ tournamentId }: { tournamentId: string }) {
  const pathname = usePathname();
  return (
    <div className="-mx-4 mb-6 overflow-x-auto border-b border-line px-4 sm:mx-0 sm:px-0">
      <div className="flex gap-1 whitespace-nowrap pb-px">
        {TABS.map((tab) => {
          const href = `/tournaments/${tournamentId}/${tab.slug}`;
          const active = pathname === href;
          return (
            <Link
              key={tab.slug}
              href={href}
              className={`rounded-t-lg px-3.5 py-2.5 text-sm font-medium transition ${
                active ? "border-b-2 border-accent text-white" : "border-b-2 border-transparent text-white/50 hover:text-white/80"
              }`}
            >
              {tab.label}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
