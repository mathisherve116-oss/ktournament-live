"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "./AuthProvider";

const ROLE_LABELS: Record<string, string> = {
  admin: "Administrateur",
  club_manager: "Responsable club",
  tournament_manager: "Responsable tournoi",
  score_volunteer: "Benevole score",
  screen_manager: "Responsable ecran",
  public: "Public",
};

export function BackofficeShell({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const router = useRouter();

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-line bg-ink/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <Link href="/dashboard" className="text-lg font-black tracking-tight text-white">
            K'<span className="text-accent">TOURNAMENT</span> LIVE
          </Link>
          {user && (
            <div className="flex items-center gap-3 text-sm">
              <div className="hidden text-right sm:block">
                <div className="font-semibold text-white">{user.firstName} {user.lastName}</div>
                <div className="text-xs text-white/40">{ROLE_LABELS[user.role] || user.role}</div>
              </div>
              <button
                onClick={async () => { await logout(); router.replace("/login"); }}
                className="rounded-lg border border-line px-3 py-1.5 text-xs font-semibold text-white/70 hover:bg-white/5"
              >
                Deconnexion
              </button>
            </div>
          )}
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">{children}</main>
    </div>
  );
}
