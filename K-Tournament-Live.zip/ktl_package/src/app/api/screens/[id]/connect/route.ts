import { NextRequest } from "next/server";
import { ok, requirePermission } from "@/lib/api-helpers";
import { setScreenStatus, getScreen } from "@/lib/repo";
import { emitToTournament } from "@/lib/socket";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "screens", "connect");
  if (!user) return response!;
  const screen = setScreenStatus(params.id, "online");
  if (screen) emitToTournament(screen.tournamentId, "screen.connected", { screenId: params.id });
  return ok(screen);
}
