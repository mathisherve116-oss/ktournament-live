import { NextRequest } from "next/server";
import { ok, requirePermission } from "@/lib/api-helpers";
import { setScreenStatus } from "@/lib/repo";
import { emitToTournament } from "@/lib/socket";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "screens", "disconnect");
  if (!user) return response!;
  const screen = setScreenStatus(params.id, "offline");
  if (screen) emitToTournament(screen.tournamentId, "screen.disconnected", { screenId: params.id });
  return ok(screen);
}
