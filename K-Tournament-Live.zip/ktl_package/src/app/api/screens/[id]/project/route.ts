import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { projectContent, getScreen, logAudit } from "@/lib/repo";
import { emitToTournament, emitToScreen } from "@/lib/socket";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "screens", "project");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.contentType) return fail("contentType requis");
  const session = projectContent(params.id, body.contentType, body.payload, user.id);
  const screen = getScreen(params.id);
  logAudit({ userId: user.id, action: "screen.project", entityType: "screen", entityId: params.id, newValue: { contentType: body.contentType } });
  if (screen) emitToTournament(screen.tournamentId, "screen.contentChanged", { screenId: params.id, contentType: body.contentType });
  emitToScreen(params.id, "screen.contentChanged", { screenId: params.id, contentType: body.contentType, payload: body.payload });
  return ok(session);
}
