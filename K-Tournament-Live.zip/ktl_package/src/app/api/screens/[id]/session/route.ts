import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/api-helpers";
import { getScreenSession, getScreen } from "@/lib/repo";

// Route publique en lecture seule : le navigateur du K'Screen (TV/videoprojecteur)
// n'a pas de compte, il affiche uniquement des donnees publiques de projection.
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const screen = getScreen(params.id);
  if (!screen) return fail("Ecran introuvable", 404);
  return ok({ screen, session: getScreenSession(params.id) });
}
