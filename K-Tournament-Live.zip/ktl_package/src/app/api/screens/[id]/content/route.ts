import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/api-helpers";
import {
  getScreen, getScreenSession, getTournament, listCategories, listMatches,
  getGroupRankings, listGroups, listSponsors, getPublicLinkByTournament,
} from "@/lib/repo";

// Route publique en lecture seule utilisee par le navigateur K'Screen (TV/videoprojecteur)
// pour recuperer, en un seul appel, tout ce qu'il doit afficher selon le contenu pilote par K'Remote.
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const screen = getScreen(params.id);
  if (!screen) return fail("Ecran introuvable", 404);
  const session = getScreenSession(params.id);
  const tournament = getTournament(screen.tournamentId);
  if (!tournament) return fail("Tournoi introuvable", 404);

  const payload = (session?.currentPayload || {}) as { categoryId?: string; groupId?: string; message?: string };
  const sponsors = listSponsors(tournament.id).filter((s) => s.status === "active");
  const publicLink = getPublicLinkByTournament(tournament.id);
  const contentType = session?.activeContentType || "home";

  const base = { screen, session, tournament, sponsors, publicSlug: publicLink?.slug, contentType };

  if (contentType === "live" || contentType === "planning") {
    const matches = listMatches(tournament.id, { categoryId: payload.categoryId });
    return ok({ ...base, matches });
  }
  if (contentType === "rankings") {
    let groupId = payload.groupId;
    if (!groupId && payload.categoryId) {
      const groups = listGroups(tournament.id, payload.categoryId);
      groupId = groups[0]?.id;
    }
    const rankings = groupId ? getGroupRankings(groupId) : [];
    return ok({ ...base, rankings });
  }
  if (contentType === "message") {
    return ok({ ...base, message: payload.message || "" });
  }
  const categories = listCategories(tournament.id);
  return ok({ ...base, categories });
}
