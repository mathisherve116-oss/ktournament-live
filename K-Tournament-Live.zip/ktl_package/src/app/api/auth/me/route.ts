import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ data: null, errors: [{ message: "Non authentifie" }] }, { status: 401 });
  return NextResponse.json({
    data: { id: user.id, firstName: user.firstName, lastName: user.lastName, email: user.email, role: user.role, clubId: user.clubId },
    errors: [],
  });
}
