import { NextRequest, NextResponse } from "next/server";
import { getUserByEmail, touchLogin, logAudit } from "@/lib/repo";
import { verifyPassword, signToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const email = body?.email?.toString().toLowerCase().trim();
  const password = body?.password?.toString();

  if (!email || !password) {
    return NextResponse.json({ data: null, errors: [{ message: "Email et mot de passe requis" }] }, { status: 400 });
  }

  const user = getUserByEmail(email);
  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return NextResponse.json({ data: null, errors: [{ message: "Identifiants invalides" }] }, { status: 401 });
  }
  if (user.status !== "active") {
    return NextResponse.json({ data: null, errors: [{ message: "Compte desactive" }] }, { status: 403 });
  }

  const token = signToken({ sub: user.id, email: user.email, role: user.role, clubId: user.clubId });
  touchLogin(user.id);
  logAudit({ userId: user.id, action: "user.login", entityType: "user", entityId: user.id });

  const res = NextResponse.json({
    data: {
      token,
      user: { id: user.id, firstName: user.firstName, lastName: user.lastName, email: user.email, role: user.role, clubId: user.clubId },
    },
    errors: [],
  });
  res.cookies.set("ktl_token", token, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 12 });
  return res;
}
