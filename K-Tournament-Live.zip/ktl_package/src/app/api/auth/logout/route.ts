import { NextResponse } from "next/server";

export async function POST() {
  const res = NextResponse.json({ data: { ok: true }, errors: [] });
  res.cookies.set("ktl_token", "", { path: "/", maxAge: 0 });
  return res;
}
