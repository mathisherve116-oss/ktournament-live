import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { updateTeam, deleteTeam, logAudit } from "@/lib/repo";

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "teams", "update");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const team = updateTeam(params.id, body);
  if (!team) return fail("Equipe introuvable", 404);
  logAudit({ userId: user.id, action: "team.update", entityType: "team", entityId: params.id, newValue: body });
  return ok(team);
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "teams", "delete");
  if (!user) return response!;
  deleteTeam(params.id);
  logAudit({ userId: user.id, action: "team.delete", entityType: "team", entityId: params.id });
  return ok({ ok: true });
}
