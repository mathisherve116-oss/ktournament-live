import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { updateCategory, deleteCategory, logAudit } from "@/lib/repo";

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "categories", "update");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const category = updateCategory(params.id, body);
  if (!category) return fail("Categorie introuvable", 404);
  logAudit({ userId: user.id, action: "category.update", entityType: "category", entityId: params.id, newValue: body });
  return ok(category);
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "categories", "delete");
  if (!user) return response!;
  deleteCategory(params.id);
  logAudit({ userId: user.id, action: "category.delete", entityType: "category", entityId: params.id });
  return ok({ ok: true });
}
