import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { autoGenerateGroups, listGroupTeams, logAudit } from "@/lib/repo";

export async function POST(req: NextRequest) {
  const { user, response } = await requirePermission(req, "groups", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const { categoryId, groupsCount } = body || {};
  if (!categoryId || !groupsCount) return fail("categoryId et groupsCount requis");
  const groups = autoGenerateGroups(categoryId, Number(groupsCount));
  const withTeams = groups.map((g) => ({ ...g, teams: listGroupTeams(g.id) }));
  logAudit({ userId: user.id, action: "group.autoGenerate", entityType: "category", entityId: categoryId, newValue: { groupsCount } });
  return ok(withTeams, 201);
}
