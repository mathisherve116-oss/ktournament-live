import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { validateGroup, logAudit } from "@/lib/repo";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "groups", "update");
  if (!user) return response!;
  const group = validateGroup(params.id);
  if (!group) return fail("Poule introuvable", 404);
  logAudit({ userId: user.id, action: "group.validate", entityType: "group", entityId: params.id });
  return ok(group);
}
