import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { getGroup, listGroupTeams } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "groups", "read");
  if (!user) return response!;
  const group = getGroup(params.id);
  if (!group) return fail("Poule introuvable", 404);
  return ok({ ...group, teams: listGroupTeams(params.id) });
}
