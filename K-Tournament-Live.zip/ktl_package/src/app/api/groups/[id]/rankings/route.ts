import { NextRequest } from "next/server";
import { ok, requirePermission } from "@/lib/api-helpers";
import { getGroupRankings } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "rankings", "read");
  if (!user) return response!;
  return ok(getGroupRankings(params.id));
}
