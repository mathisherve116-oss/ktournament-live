import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { listTournaments, createTournament } from "@/lib/repo";
import { logAudit } from "@/lib/repo";

export async function GET(req: NextRequest) {
  const { user, response } = await requirePermission(req, "tournaments", "read");
  if (!user) return response!;
  return ok(listTournaments());
}

export async function POST(req: NextRequest) {
  const { user, response } = await requirePermission(req, "tournaments", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => null);
  if (!body?.name || !body?.startDate || !body?.endDate) return fail("name, startDate et endDate sont requis");
  const clubId = user.clubId || body.clubId;
  if (!clubId) return fail("clubId requis");
  const tournament = createTournament({ clubId, name: body.name, startDate: body.startDate, endDate: body.endDate, location: body.location, city: body.city, mainCategory: body.mainCategory });
  logAudit({ userId: user.id, action: "tournament.create", entityType: "tournament", entityId: tournament.id, newValue: tournament });
  return ok(tournament, 201);
}
