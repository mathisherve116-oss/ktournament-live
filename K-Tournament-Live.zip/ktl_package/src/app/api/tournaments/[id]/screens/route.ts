import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { listScreens, createScreen, getScreenSession, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "screens", "read");
  if (!user) return response!;
  const screens = listScreens(params.id).map((s) => ({ ...s, session: getScreenSession(s.id) }));
  return ok(screens);
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "screens", "create" as never);
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.name) return fail("name requis");
  const screen = createScreen({ tournamentId: params.id, name: body.name, type: body.type, location: body.location });
  logAudit({ userId: user.id, action: "screen.create", entityType: "screen", entityId: screen.id });
  return ok(screen, 201);
}
