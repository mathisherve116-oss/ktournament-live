import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { getPublicLinkByTournament, togglePublicLink, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "tournaments", "read");
  if (!user) return response!;
  const link = getPublicLinkByTournament(params.id);
  if (!link) return fail("Lien introuvable", 404);
  return ok(link);
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "tournaments", "update");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const status = body?.status === "disabled" ? "disabled" : "active";
  const link = togglePublicLink(params.id, status);
  logAudit({ userId: user.id, action: "publicLink.toggle", entityType: "tournament", entityId: params.id, newValue: { status } });
  return ok(link);
}
