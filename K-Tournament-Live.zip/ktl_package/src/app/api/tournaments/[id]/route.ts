import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { getTournament, updateTournament, deleteTournament, logAudit, getPublicLinkByTournament } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "tournaments", "read");
  if (!user) return response!;
  const tournament = getTournament(params.id);
  if (!tournament) return fail("Tournoi introuvable", 404);
  const publicLink = getPublicLinkByTournament(params.id);
  return ok({ ...tournament, publicSlug: publicLink?.slug, publicStatus: publicLink?.status });
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "tournaments", "update");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const tournament = updateTournament(params.id, body);
  if (!tournament) return fail("Tournoi introuvable", 404);
  logAudit({ userId: user.id, action: "tournament.update", entityType: "tournament", entityId: params.id, newValue: body });
  return ok(tournament);
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "tournaments", "delete");
  if (!user) return response!;
  deleteTournament(params.id);
  logAudit({ userId: user.id, action: "tournament.delete", entityType: "tournament", entityId: params.id });
  return ok({ ok: true });
}
