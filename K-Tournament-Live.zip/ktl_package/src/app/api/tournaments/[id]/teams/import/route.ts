import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { createTeam, logAudit } from "@/lib/repo";

// Import CSV simple : colonnes attendues "name,clubName,managerName,categoryId"
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "teams", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const csv = body?.csv as string | undefined;
  if (!csv) return fail("Champ csv requis (texte CSV)");

  const lines = csv.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const header = lines[0]?.toLowerCase().split(",").map((h) => h.trim());
  const rows = lines.slice(1);
  const created = [];
  const errors: string[] = [];

  for (const [i, line] of rows.entries()) {
    const cols = line.split(",").map((c) => c.trim());
    const rec: Record<string, string> = {};
    header?.forEach((h, idx) => (rec[h] = cols[idx] || ""));
    if (!rec.name || !rec.categoryid) {
      errors.push(`Ligne ${i + 2}: name et categoryId obligatoires`);
      continue;
    }
    const team = createTeam({ tournamentId: params.id, categoryId: rec.categoryid, name: rec.name, clubName: rec.clubname, managerName: rec.managername });
    created.push(team);
  }
  logAudit({ userId: user.id, action: "team.import", entityType: "team", entityId: params.id, newValue: { count: created.length } });
  return ok({ created, errors });
}
