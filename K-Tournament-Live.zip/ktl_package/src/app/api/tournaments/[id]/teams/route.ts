import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { listTeams, createTeam, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "teams", "read");
  if (!user) return response!;
  const categoryId = req.nextUrl.searchParams.get("categoryId") || undefined;
  return ok(listTeams(params.id, categoryId));
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "teams", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.name || !body?.categoryId) return fail("name et categoryId requis");
  const team = createTeam({ tournamentId: params.id, categoryId: body.categoryId, name: body.name, clubName: body.clubName, managerName: body.managerName });
  logAudit({ userId: user.id, action: "team.create", entityType: "team", entityId: team.id });
  return ok(team, 201);
}
