import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { getTournamentSettings, updateTournamentSettings, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "tournaments", "read");
  if (!user) return response!;
  const settings = getTournamentSettings(params.id);
  if (!settings) return fail("Parametres introuvables", 404);
  return ok(settings);
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "categories", "update");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const settings = updateTournamentSettings(params.id, body);
  if (!settings) return fail("Parametres introuvables", 404);
  logAudit({ userId: user.id, action: "tournament.settings.update", entityType: "tournament", entityId: params.id, newValue: body });
  return ok(settings);
}
