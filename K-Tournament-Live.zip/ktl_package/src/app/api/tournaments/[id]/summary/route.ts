import { NextRequest } from "next/server";
import { ok, requirePermission } from "@/lib/api-helpers";
import { getTournament, listCategories, listTeams, listMatches, listSponsors, listScreens, getPublicLinkByTournament } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "tournaments", "read");
  if (!user) return response!;
  const tournament = getTournament(params.id);
  const categories = listCategories(params.id);
  const teams = listTeams(params.id);
  const matches = listMatches(params.id);
  const sponsors = listSponsors(params.id);
  const screens = listScreens(params.id);
  const publicLink = getPublicLinkByTournament(params.id);

  return ok({
    tournament,
    stats: {
      categories: categories.length,
      teams: teams.length,
      matches: matches.length,
      matchesFinished: matches.filter((m) => m.status === "finished").length,
      matchesLive: matches.filter((m) => m.status === "live").length,
      sponsors: sponsors.length,
      screens: screens.length,
      screensOnline: screens.filter((s) => s.status !== "offline").length,
    },
    publicLink,
  });
}
