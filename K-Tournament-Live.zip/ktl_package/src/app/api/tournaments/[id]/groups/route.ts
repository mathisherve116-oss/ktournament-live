import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { listGroups, createGroup, listGroupTeams, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "groups", "read");
  if (!user) return response!;
  const categoryId = req.nextUrl.searchParams.get("categoryId") || undefined;
  const groups = listGroups(params.id, categoryId);
  const withTeams = groups.map((g) => ({ ...g, teams: listGroupTeams(g.id) }));
  return ok(withTeams);
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "groups", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.name || !body?.categoryId) return fail("name et categoryId requis");
  const group = createGroup({ tournamentId: params.id, categoryId: body.categoryId, name: body.name });
  logAudit({ userId: user.id, action: "group.create", entityType: "group", entityId: group.id });
  return ok(group, 201);
}
