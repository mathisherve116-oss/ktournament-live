import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { listSponsors, createSponsor, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "sponsors", "read");
  if (!user) return response!;
  return ok(listSponsors(params.id));
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "sponsors", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.name) return fail("name requis");
  const sponsor = createSponsor({ tournamentId: params.id, name: body.name, level: body.level, slogan: body.slogan, linkUrl: body.linkUrl, durationSeconds: body.durationSeconds });
  logAudit({ userId: user.id, action: "sponsor.create", entityType: "sponsor", entityId: sponsor.id });
  return ok(sponsor, 201);
}
