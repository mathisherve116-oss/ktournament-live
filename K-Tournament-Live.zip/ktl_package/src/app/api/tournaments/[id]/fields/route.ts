import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { listFields, createField, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "fields", "read");
  if (!user) return response!;
  return ok(listFields(params.id));
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "fields", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.name) return fail("name requis");
  const field = createField({ tournamentId: params.id, name: body.name, type: body.type, color: body.color, location: body.location });
  logAudit({ userId: user.id, action: "field.create", entityType: "field", entityId: field.id });
  return ok(field, 201);
}
