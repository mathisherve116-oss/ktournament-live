import { NextRequest } from "next/server";
import { ok, requirePermission } from "@/lib/api-helpers";
import { listFinalPhases } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "finals", "read");
  if (!user) return response!;
  const categoryId = req.nextUrl.searchParams.get("categoryId") || undefined;
  return ok(listFinalPhases(params.id, categoryId));
}
