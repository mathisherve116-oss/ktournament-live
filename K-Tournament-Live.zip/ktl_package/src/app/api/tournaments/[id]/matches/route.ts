import { NextRequest } from "next/server";
import { ok, requirePermission } from "@/lib/api-helpers";
import { listMatches } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "matches", "read");
  if (!user) return response!;
  const categoryId = req.nextUrl.searchParams.get("categoryId") || undefined;
  const groupId = req.nextUrl.searchParams.get("groupId") || undefined;
  const status = req.nextUrl.searchParams.get("status") || undefined;
  return ok(listMatches(params.id, { categoryId, groupId, status }));
}
