import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { listCategories, createCategory, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "categories", "read");
  if (!user) return response!;
  return ok(listCategories(params.id));
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "categories", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.name) return fail("name requis");
  const category = createCategory({ tournamentId: params.id, name: body.name, ageGroup: body.ageGroup });
  logAudit({ userId: user.id, action: "category.create", entityType: "category", entityId: category.id });
  return ok(category, 201);
}
