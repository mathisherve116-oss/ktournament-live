import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { updateTournament, logAudit } from "@/lib/repo";
import { emitToTournament } from "@/lib/socket";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "tournaments", "finish");
  if (!user) return response!;
  const tournament = updateTournament(params.id, { status: "finished" });
  if (!tournament) return fail("Tournoi introuvable", 404);
  logAudit({ userId: user.id, action: "tournament.finish", entityType: "tournament", entityId: params.id });
  emitToTournament(params.id, "tournament.updated", { tournamentId: params.id, status: "finished" });
  return ok(tournament);
}
