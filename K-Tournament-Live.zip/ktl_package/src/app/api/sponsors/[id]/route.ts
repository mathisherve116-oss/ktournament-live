import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { updateSponsor, deleteSponsor, logAudit } from "@/lib/repo";

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "sponsors", "update");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const sponsor = updateSponsor(params.id, body);
  if (!sponsor) return fail("Sponsor introuvable", 404);
  logAudit({ userId: user.id, action: "sponsor.update", entityType: "sponsor", entityId: params.id, newValue: body });
  return ok(sponsor);
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "sponsors", "delete");
  if (!user) return response!;
  deleteSponsor(params.id);
  logAudit({ userId: user.id, action: "sponsor.delete", entityType: "sponsor", entityId: params.id });
  return ok({ ok: true });
}
