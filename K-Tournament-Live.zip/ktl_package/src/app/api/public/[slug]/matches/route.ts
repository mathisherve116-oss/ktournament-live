import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/api-helpers";
import { getTournamentBySlug, listMatches } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { slug: string } }) {
  const tournament = getTournamentBySlug(params.slug);
  if (!tournament) return fail("Tournoi introuvable ou lien desactive", 404);
  const categoryId = req.nextUrl.searchParams.get("categoryId") || undefined;
  return ok(listMatches(tournament.id, { categoryId }));
}
