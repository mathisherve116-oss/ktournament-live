import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/api-helpers";
import { getTournamentBySlug, listCategories, listFields, getTournamentSettings } from "@/lib/repo";

export async function GET(_req: NextRequest, { params }: { params: { slug: string } }) {
  const tournament = getTournamentBySlug(params.slug);
  if (!tournament) return fail("Tournoi introuvable ou lien desactive", 404);
  return ok({
    tournament,
    categories: listCategories(tournament.id),
    fields: listFields(tournament.id),
    settings: getTournamentSettings(tournament.id),
  });
}
