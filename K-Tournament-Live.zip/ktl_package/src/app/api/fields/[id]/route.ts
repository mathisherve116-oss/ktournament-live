import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { updateField, deleteField, logAudit } from "@/lib/repo";

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "fields", "update");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const field = updateField(params.id, body);
  if (!field) return fail("Terrain introuvable", 404);
  logAudit({ userId: user.id, action: "field.update", entityType: "field", entityId: params.id, newValue: body });
  return ok(field);
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "fields", "delete");
  if (!user) return response!;
  deleteField(params.id);
  logAudit({ userId: user.id, action: "field.delete", entityType: "field", entityId: params.id });
  return ok({ ok: true });
}
