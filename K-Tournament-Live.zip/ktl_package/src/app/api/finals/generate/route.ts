import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { generateFinalPhase, logAudit } from "@/lib/repo";
import { emitToTournament } from "@/lib/socket";

export async function POST(req: NextRequest) {
  const { user, response } = await requirePermission(req, "finals", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const { categoryId, round, qualifiedTeamIds, startTime, slotMinutes, fieldId } = body || {};
  if (!categoryId || !round || !qualifiedTeamIds?.length || !startTime || !slotMinutes) {
    return fail("categoryId, round, qualifiedTeamIds, startTime et slotMinutes requis");
  }
  const phases = generateFinalPhase(categoryId, round, qualifiedTeamIds, { startTime, slotMinutes: Number(slotMinutes), fieldId });
  logAudit({ userId: user.id, action: "final.generate", entityType: "category", entityId: categoryId, newValue: { round } });
  if (phases[0]) emitToTournament(phases[0].tournamentId, "tournament.updated", { categoryId, round });
  return ok(phases, 201);
}
