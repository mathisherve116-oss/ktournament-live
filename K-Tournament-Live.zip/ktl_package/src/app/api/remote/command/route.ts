import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { getScreen, logAudit } from "@/lib/repo";
import { emitToScreen, emitToTournament } from "@/lib/socket";

// Commandes rapides depuis K'Remote : next-match, refresh, sponsor-loop, home...
export async function POST(req: NextRequest) {
  const { user, response } = await requirePermission(req, "remote", "command" as never);
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const { screenId, command, payload } = body || {};
  if (!screenId || !command) return fail("screenId et command requis");
  const screen = getScreen(screenId);
  logAudit({ userId: user.id, action: `remote.command.${command}`, entityType: "screen", entityId: screenId });
  emitToScreen(screenId, "remote.command", { command, payload });
  if (screen) emitToTournament(screen.tournamentId, "screen.contentChanged", { screenId, command });
  return ok({ ok: true });
}
