import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { stopProjection, getScreen, logAudit } from "@/lib/repo";
import { emitToScreen, emitToTournament } from "@/lib/socket";

export async function POST(req: NextRequest) {
  const { user, response } = await requirePermission(req, "remote", "stop" as never);
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const { screenId } = body || {};
  if (!screenId) return fail("screenId requis");
  const session = stopProjection(screenId);
  const screen = getScreen(screenId);
  logAudit({ userId: user.id, action: "remote.stop", entityType: "screen", entityId: screenId });
  emitToScreen(screenId, "screen.contentChanged", { screenId, contentType: "idle" });
  if (screen) emitToTournament(screen.tournamentId, "sponsor.rotationStopped", { screenId });
  return ok(session);
}
