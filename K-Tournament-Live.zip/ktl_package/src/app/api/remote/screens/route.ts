import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { listScreens, getScreenSession } from "@/lib/repo";

export async function GET(req: NextRequest) {
  const { user, response } = await requirePermission(req, "remote", "select-screen" as never);
  if (!user) return response!;
  const tournamentId = req.nextUrl.searchParams.get("tournamentId");
  if (!tournamentId) return fail("tournamentId requis");
  const screens = listScreens(tournamentId).map((s) => ({ ...s, session: getScreenSession(s.id) }));
  return ok(screens);
}
