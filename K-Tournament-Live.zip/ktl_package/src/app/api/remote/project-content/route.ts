import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { projectContent, getScreen, logAudit } from "@/lib/repo";
import { emitToTournament, emitToScreen } from "@/lib/socket";

export async function POST(req: NextRequest) {
  const { user, response } = await requirePermission(req, "remote", "project-content" as never);
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const { screenId, contentType, payload } = body || {};
  if (!screenId || !contentType) return fail("screenId et contentType requis");
  const session = projectContent(screenId, contentType, payload, user.id);
  const screen = getScreen(screenId);
  logAudit({ userId: user.id, action: "remote.projectContent", entityType: "screen", entityId: screenId, newValue: { contentType } });
  if (screen) emitToTournament(screen.tournamentId, "screen.contentChanged", { screenId, contentType });
  emitToScreen(screenId, "screen.contentChanged", { screenId, contentType, payload });
  return ok(session);
}
