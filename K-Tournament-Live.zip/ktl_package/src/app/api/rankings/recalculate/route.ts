import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { recalculateGroupRanking, getGroup, logAudit } from "@/lib/repo";
import { emitToTournament } from "@/lib/socket";

export async function POST(req: NextRequest) {
  const { user, response } = await requirePermission(req, "rankings", "read");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.groupId) return fail("groupId requis");
  const rankings = recalculateGroupRanking(body.groupId);
  const group = getGroup(body.groupId);
  logAudit({ userId: user.id, action: "ranking.recalculate", entityType: "group", entityId: body.groupId });
  if (group) emitToTournament(group.tournamentId, "ranking.updated", { groupId: body.groupId });
  return ok(rankings);
}
