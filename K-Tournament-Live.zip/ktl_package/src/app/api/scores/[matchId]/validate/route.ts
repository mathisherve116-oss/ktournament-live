import { NextRequest } from "next/server";
import { ok, requirePermission } from "@/lib/api-helpers";
import { validateScore, getMatch, recalculateGroupRanking, logAudit } from "@/lib/repo";
import { emitToTournament } from "@/lib/socket";

export async function POST(req: NextRequest, { params }: { params: { matchId: string } }) {
  const { user, response } = await requirePermission(req, "scores", "validate");
  if (!user) return response!;
  const score = validateScore(params.matchId, user.id);
  const match = getMatch(params.matchId);
  let rankings = null;
  if (match?.groupId) rankings = recalculateGroupRanking(match.groupId);
  logAudit({ userId: user.id, action: "score.validate", entityType: "match", entityId: params.matchId });
  if (match) {
    emitToTournament(match.tournamentId, "match.finished", { matchId: params.matchId });
    if (match.groupId) emitToTournament(match.tournamentId, "ranking.updated", { groupId: match.groupId });
  }
  return ok({ score, rankings });
}
