import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { getMatch, updateMatch, logAudit } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "matches", "read");
  if (!user) return response!;
  const match = getMatch(params.id);
  if (!match) return fail("Match introuvable", 404);
  return ok(match);
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "matches", "update");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const match = updateMatch(params.id, body);
  if (!match) return fail("Match introuvable", 404);
  logAudit({ userId: user.id, action: "match.update", entityType: "match", entityId: params.id, newValue: body });
  return ok(match);
}
