import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { addMatchEvent, listMatchEvents } from "@/lib/repo";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "matches", "read");
  if (!user) return response!;
  return ok(listMatchEvents(params.id));
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "scores", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  if (!body?.eventType) return fail("eventType requis");
  addMatchEvent({ matchId: params.id, teamId: body.teamId, eventType: body.eventType, minute: body.minute, createdBy: user.id });
  return ok(listMatchEvents(params.id));
}
