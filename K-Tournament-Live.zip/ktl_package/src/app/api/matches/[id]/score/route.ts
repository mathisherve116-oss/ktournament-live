import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { submitScore, getMatch } from "@/lib/repo";
import { emitToTournament } from "@/lib/socket";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "scores", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const homeScore = Number(body?.homeScore);
  const awayScore = Number(body?.awayScore);
  if (Number.isNaN(homeScore) || Number.isNaN(awayScore)) return fail("homeScore et awayScore requis");
  const score = submitScore(params.id, homeScore, awayScore, user.id);
  const match = getMatch(params.id);
  if (match) emitToTournament(match.tournamentId, "score.updated", { matchId: params.id, homeScore, awayScore });
  return ok(score);
}
