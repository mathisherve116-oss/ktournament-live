import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { getMatch, updateMatchStatus, logAudit } from "@/lib/repo";
import { emitToTournament } from "@/lib/socket";

const STATUS_MAP: Record<string, string> = { start: "live", pause: "paused", resume: "live", finish: "finished" };
const EVENT_MAP: Record<string, string> = { start: "match.started", pause: "match.paused", resume: "match.resumed", finish: "match.finished" };

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { user, response } = await requirePermission(req, "matches", "start");
  if (!user) return response!;
  const match = updateMatchStatus(params.id, STATUS_MAP["start"]);
  if (!match) return fail("Match introuvable", 404);
  logAudit({ userId: user.id, action: "match.start", entityType: "match", entityId: params.id });
  emitToTournament(match.tournamentId, EVENT_MAP["start"], { matchId: params.id, status: match.status });
  return ok(match);
}
