import { NextRequest } from "next/server";
import { ok, fail, requirePermission } from "@/lib/api-helpers";
import { generateMatchesForCategory, logAudit } from "@/lib/repo";

export async function POST(req: NextRequest) {
  const { user, response } = await requirePermission(req, "matches", "create");
  if (!user) return response!;
  const body = await req.json().catch(() => ({}));
  const { categoryId, startTime, slotMinutes, fieldIds } = body || {};
  if (!categoryId || !startTime || !slotMinutes) return fail("categoryId, startTime et slotMinutes requis");
  const matches = generateMatchesForCategory(categoryId, { startTime, slotMinutes: Number(slotMinutes), fieldIds: fieldIds || [] });
  logAudit({ userId: user.id, action: "match.generate", entityType: "category", entityId: categoryId, newValue: { count: matches.length } });
  return ok(matches, 201);
}
