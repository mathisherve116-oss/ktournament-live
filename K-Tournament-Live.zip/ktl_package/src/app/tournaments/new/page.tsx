"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { RequireAuth } from "@/components/RequireAuth";
import { BackofficeShell } from "@/components/BackofficeShell";
import { Button, Card, Field, Input, PageHeader } from "@/components/ui";
import { apiPost } from "@/lib/api-client";

function NewTournamentContent() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", startDate: "", endDate: "", location: "", city: "", mainCategory: "" });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    const res = await apiPost<{ id: string }>("/api/tournaments", form);
    setSubmitting(false);
    if (res.data) router.push(`/tournaments/${res.data.id}/settings`);
    else setError(res.errors[0]?.message || "Impossible de creer le tournoi");
  }

  return (
    <BackofficeShell>
      <PageHeader eyebrow="Ecran 03" title="Creer un tournoi" subtitle="Les informations de base — vous affinerez la configuration ensuite." />
      <Card className="max-w-2xl">
        <form onSubmit={onSubmit} className="space-y-4">
          <Field label="Nom du tournoi">
            <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex: Tournoi Ete U11" />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Date de debut">
              <Input required type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
            </Field>
            <Field label="Date de fin">
              <Input required type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Lieu">
              <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Complexe sportif..." />
            </Field>
            <Field label="Ville">
              <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            </Field>
          </div>
          <Field label="Categorie principale">
            <Input value={form.mainCategory} onChange={(e) => setForm({ ...form, mainCategory: e.target.value })} placeholder="Ex: U11" />
          </Field>
          {error && <p className="text-sm text-danger">{error}</p>}
          <Button type="submit" disabled={submitting}>{submitting ? "Creation..." : "Creer le tournoi"}</Button>
        </form>
      </Card>
    </BackofficeShell>
  );
}

export default function NewTournamentPage() {
  return (
    <RequireAuth>
      <NewTournamentContent />
    </RequireAuth>
  );
}
