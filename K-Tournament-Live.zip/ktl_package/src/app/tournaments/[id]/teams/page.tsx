"use client";
import { useEffect, useState } from "react";
import { PageHeader, Card, Field, Input, Select, Textarea, Button, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost, apiDelete } from "@/lib/api-client";

interface Category { id: string; name: string; }
interface Team { id: string; name: string; clubName: string | null; categoryId: string; status: string; }

export default function TeamsPage({ params }: { params: { id: string } }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [teams, setTeams] = useState<Team[] | null>(null);
  const [form, setForm] = useState({ name: "", clubName: "", categoryId: "" });
  const [csv, setCsv] = useState("");
  const [importResult, setImportResult] = useState<string | null>(null);

  async function load() {
    const [catRes, teamRes] = await Promise.all([
      apiGet<Category[]>(`/api/tournaments/${params.id}/categories`),
      apiGet<Team[]>(`/api/tournaments/${params.id}/teams`),
    ]);
    setCategories(catRes.data || []);
    setTeams(teamRes.data || []);
    if (!form.categoryId && catRes.data?.[0]) setForm((f) => ({ ...f, categoryId: catRes.data![0].id }));
  }
  useEffect(() => { load(); }, [params.id]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.categoryId) return;
    await apiPost(`/api/tournaments/${params.id}/teams`, form);
    setForm({ ...form, name: "", clubName: "" });
    await load();
  }

  async function remove(id: string) {
    await apiDelete(`/api/teams/${id}`);
    await load();
  }

  async function importCsv(e: React.FormEvent) {
    e.preventDefault();
    const res = await apiPost<{ created: unknown[]; errors: string[] }>(`/api/tournaments/${params.id}/teams/import`, { csv });
    if (res.data) setImportResult(`${res.data.created.length} equipe(s) importee(s)${res.data.errors.length ? `, ${res.data.errors.length} erreur(s)` : ""}.`);
    setCsv("");
    await load();
  }

  const categoryName = (id: string) => categories.find((c) => c.id === id)?.name || "—";

  return (
    <div>
      <PageHeader eyebrow="Ecrans 07 · 10" title="Equipes" subtitle="Inscription manuelle ou import en masse depuis un fichier CSV." />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-1">
          <Card>
            <h3 className="mb-3 font-bold text-white">Ajouter une equipe</h3>
            <form onSubmit={onSubmit} className="space-y-3">
              <Field label="Categorie">
                <Select value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
                  {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </Select>
              </Field>
              <Field label="Nom de l'equipe"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
              <Field label="Club"><Input value={form.clubName} onChange={(e) => setForm({ ...form, clubName: e.target.value })} /></Field>
              <Button type="submit" className="w-full" disabled={!categories.length}>Ajouter</Button>
            </form>
          </Card>
          <Card>
            <h3 className="mb-3 font-bold text-white">Import CSV</h3>
            <p className="mb-2 text-xs text-white/40">Colonnes : name,clubName,managerName,categoryId</p>
            <form onSubmit={importCsv} className="space-y-3">
              <Textarea rows={5} value={csv} onChange={(e) => setCsv(e.target.value)} placeholder={`name,clubName,managerName,categoryId\nFC Lyon,FC Lyon,Jean,${categories[0]?.id || "..."}`} />
              <Button type="submit" variant="secondary" className="w-full">Importer</Button>
              {importResult && <p className="text-xs text-accent">{importResult}</p>}
            </form>
          </Card>
        </div>
        <div className="lg:col-span-2">
          {teams === null && <div className="flex justify-center py-10"><Spinner /></div>}
          {teams && teams.length === 0 && <EmptyState title="Aucune equipe inscrite" />}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {teams?.map((t) => (
              <Card key={t.id}>
                <h4 className="font-bold text-white">{t.name}</h4>
                <p className="text-xs text-white/40">{categoryName(t.categoryId)}</p>
                <button onClick={() => remove(t.id)} className="mt-3 text-xs text-danger/80 hover:text-danger">Retirer</button>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
