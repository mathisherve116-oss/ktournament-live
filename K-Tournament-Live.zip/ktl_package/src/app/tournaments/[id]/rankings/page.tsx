"use client";
import { useCallback, useEffect, useState } from "react";
import { PageHeader, Card, Field, Select, Button, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api-client";
import { useRealtimeRoom } from "@/lib/useSocket";

interface Category { id: string; name: string; }
interface Group { id: string; name: string; }
interface Ranking {
  teamId: string; teamName: string; played: number; wins: number; draws: number; losses: number; gf: number; ga: number; diff: number; points: number; rank: number;
}

export default function RankingsPage({ params }: { params: { id: string } }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [groups, setGroups] = useState<Group[]>([]);
  const [rankingsByGroup, setRankingsByGroup] = useState<Record<string, Ranking[]>>({});

  const loadGroups = useCallback(async (catId: string) => {
    if (!catId) return;
    const res = await apiGet<{ id: string; name: string }[]>(`/api/tournaments/${params.id}/groups?categoryId=${catId}`);
    setGroups(res.data || []);
    for (const g of res.data || []) {
      const r = await apiGet<Ranking[]>(`/api/groups/${g.id}/rankings`);
      setRankingsByGroup((prev) => ({ ...prev, [g.id]: r.data || [] }));
    }
  }, [params.id]);

  useEffect(() => {
    apiGet<Category[]>(`/api/tournaments/${params.id}/categories`).then((res) => {
      setCategories(res.data || []);
      if (res.data?.[0]) setCategoryId(res.data[0].id);
    });
  }, [params.id]);

  useEffect(() => { if (categoryId) loadGroups(categoryId); }, [categoryId, loadGroups]);

  useRealtimeRoom(`tournament:${params.id}`, { "ranking.updated": () => loadGroups(categoryId) });

  async function recalcAll() {
    for (const g of groups) await apiPost("/api/rankings/recalculate", { groupId: g.id });
    await loadGroups(categoryId);
  }

  return (
    <div>
      <PageHeader
        eyebrow="Ecran 16"
        title="Classements automatiques"
        subtitle="Calcul en direct : points, difference de buts, buts marques, confrontation directe."
        actions={<Button variant="secondary" onClick={recalcAll}>Recalculer</Button>}
      />
      <Card className="mb-6 max-w-sm">
        <Field label="Categorie">
          <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </Field>
      </Card>

      {groups.length === 0 && <EmptyState title="Aucune poule pour cette categorie" />}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {groups.map((g) => (
          <Card key={g.id} className="overflow-x-auto p-0">
            <div className="border-b border-line px-4 py-3 font-bold text-white">{g.name}</div>
            {!rankingsByGroup[g.id] ? <div className="flex justify-center py-8"><Spinner /></div> : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wide text-white/40">
                    <th className="px-3 py-2">#</th><th className="px-3 py-2">Equipe</th><th className="px-2 py-2">J</th>
                    <th className="px-2 py-2">G</th><th className="px-2 py-2">N</th><th className="px-2 py-2">P</th>
                    <th className="px-2 py-2">Diff</th><th className="px-2 py-2">Pts</th>
                  </tr>
                </thead>
                <tbody>
                  {rankingsByGroup[g.id].map((r) => (
                    <tr key={r.teamId} className="border-t border-line/50">
                      <td className="px-3 py-2 font-bold text-accent">{r.rank}</td>
                      <td className="px-3 py-2 font-medium text-white">{r.teamName}</td>
                      <td className="px-2 py-2 text-white/60">{r.played}</td>
                      <td className="px-2 py-2 text-white/60">{r.wins}</td>
                      <td className="px-2 py-2 text-white/60">{r.draws}</td>
                      <td className="px-2 py-2 text-white/60">{r.losses}</td>
                      <td className="px-2 py-2 text-white/60">{r.diff > 0 ? `+${r.diff}` : r.diff}</td>
                      <td className="px-2 py-2 font-bold text-white">{r.points}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
