"use client";
import { useEffect, useState } from "react";
import { PageHeader, Card, Field, Select, Input, Button, Badge, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api-client";

interface Category { id: string; name: string; }
interface Group { id: string; name: string; }
interface Ranking { teamId: string; teamName: string; rank: number; }
interface FinalPhase { id: string; round: string; position: number; matchId: string | null; status: string; }
interface FieldRow { id: string; name: string; }

export default function FinalsPage({ params }: { params: { id: string } }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [fields, setFields] = useState<FieldRow[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [qualified, setQualified] = useState<Ranking[]>([]);
  const [round, setRound] = useState("Quart de finale");
  const [startTime, setStartTime] = useState("");
  const [phases, setPhases] = useState<FinalPhase[] | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    apiGet<Category[]>(`/api/tournaments/${params.id}/categories`).then((res) => {
      setCategories(res.data || []);
      if (res.data?.[0]) setCategoryId(res.data[0].id);
    });
    apiGet<FieldRow[]>(`/api/tournaments/${params.id}/fields`).then((res) => setFields(res.data || []));
    setStartTime(new Date().toISOString().slice(0, 16));
  }, [params.id]);

  useEffect(() => {
    if (!categoryId) return;
    apiGet<Group[]>(`/api/tournaments/${params.id}/groups?categoryId=${categoryId}`).then(async (res) => {
      const gs = res.data || [];
      setGroups(gs);
      const all: Ranking[] = [];
      for (const g of gs) {
        const r = await apiGet<Ranking[]>(`/api/groups/${g.id}/rankings`);
        all.push(...(r.data || []).slice(0, 2));
      }
      setQualified(all);
    });
    apiGet<FinalPhase[]>(`/api/tournaments/${params.id}/finals?categoryId=${categoryId}`).then((res) => setPhases(res.data || []));
  }, [categoryId, params.id]);

  async function generate() {
    if (qualified.length < 2) return;
    setBusy(true);
    await apiPost("/api/finals/generate", {
      categoryId, round,
      qualifiedTeamIds: qualified.map((q) => q.teamId),
      startTime: new Date(startTime).toISOString(),
      slotMinutes: 20,
      fieldId: fields[0]?.id,
    });
    const res = await apiGet<FinalPhase[]>(`/api/tournaments/${params.id}/finals?categoryId=${categoryId}`);
    setPhases(res.data || []);
    setBusy(false);
  }

  return (
    <div>
      <PageHeader eyebrow="Ecran 17" title="Phases finales" subtitle="Qualification automatique depuis les poules, generation du tableau final." />
      <Card className="mb-6 max-w-3xl">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-4 sm:items-end">
          <Field label="Categorie">
            <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Nom du tour">
            <Input value={round} onChange={(e) => setRound(e.target.value)} />
          </Field>
          <Field label="Debut">
            <Input type="datetime-local" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
          </Field>
          <Button onClick={generate} disabled={busy || qualified.length < 2}>{busy ? "Generation..." : "Generer le tableau"}</Button>
        </div>
        <p className="mt-3 text-xs text-white/40">{qualified.length} equipe(s) qualifiee(s) depuis {groups.length} poule(s).</p>
      </Card>

      {phases === null && <div className="flex justify-center py-10"><Spinner /></div>}
      {phases && phases.length === 0 && <EmptyState title="Aucune phase finale generee" />}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {phases?.map((p) => (
          <Card key={p.id}>
            <div className="mb-2 flex items-center justify-between">
              <span className="font-bold text-white">{p.round}</span>
              <Badge status={p.status}>{p.status}</Badge>
            </div>
            <p className="text-xs text-white/40">Position {p.position + 1}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
