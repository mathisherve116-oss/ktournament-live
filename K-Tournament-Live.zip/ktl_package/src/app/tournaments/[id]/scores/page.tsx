"use client";
import { useCallback, useEffect, useState } from "react";
import { PageHeader, Card, Button, Badge, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api-client";
import { useRealtimeRoom } from "@/lib/useSocket";

interface MatchDetail {
  id: string; teamHomeName: string; teamAwayName: string; fieldName: string | null; scheduledAt: string;
  status: string; homeScore: number | null; awayScore: number | null; groupId: string | null;
}

const STATUS_LABELS: Record<string, string> = { scheduled: "A venir", live: "En direct", paused: "Pause", finished: "Termine", cancelled: "Annule" };

export default function ScoresPage({ params }: { params: { id: string } }) {
  const [matches, setMatches] = useState<MatchDetail[] | null>(null);
  const [drafts, setDrafts] = useState<Record<string, { home: number; away: number }>>({});

  const load = useCallback(async () => {
    const res = await apiGet<MatchDetail[]>(`/api/tournaments/${params.id}/matches`);
    setMatches(res.data || []);
  }, [params.id]);

  useEffect(() => { load(); }, [load]);
  useRealtimeRoom(`tournament:${params.id}`, {
    "score.updated": load,
    "match.started": load,
    "match.paused": load,
    "match.resumed": load,
    "match.finished": load,
  });

  function draft(m: MatchDetail) {
    return drafts[m.id] || { home: m.homeScore ?? 0, away: m.awayScore ?? 0 };
  }
  function setDraft(m: MatchDetail, patch: Partial<{ home: number; away: number }>) {
    setDrafts((d) => ({ ...d, [m.id]: { ...draft(m), ...patch } }));
  }

  async function action(matchId: string, path: string) {
    await apiPost(`/api/matches/${matchId}/${path}`);
    await load();
  }

  async function saveScore(m: MatchDetail) {
    const d = draft(m);
    await apiPost(`/api/matches/${m.id}/score`, { homeScore: d.home, awayScore: d.away });
    await load();
  }

  async function validate(m: MatchDetail) {
    await saveScore(m);
    await apiPost(`/api/scores/${m.id}/validate`);
    await load();
  }

  if (!matches) return <div className="flex justify-center py-16"><Spinner /></div>;

  const active = matches.filter((m) => m.status === "scheduled" || m.status === "live" || m.status === "paused");
  const finished = matches.filter((m) => m.status === "finished");

  return (
    <div>
      <PageHeader eyebrow="Ecrans 13 · 14 · 15" title="Score live" subtitle="Saisie, correction et validation des scores en temps reel." />

      <h3 className="mb-3 font-bold text-white">Matchs en cours et a venir</h3>
      {active.length === 0 && <EmptyState title="Aucun match en attente" />}
      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {active.map((m) => {
          const d = draft(m);
          return (
            <Card key={m.id}>
              <div className="mb-3 flex items-center justify-between">
                <Badge status={m.status}>{STATUS_LABELS[m.status]}</Badge>
                <span className="text-xs text-white/40">{m.fieldName}</span>
              </div>
              <div className="mb-3 grid grid-cols-5 items-center gap-2 text-center">
                <div className="col-span-2 truncate text-sm font-semibold text-white">{m.teamHomeName}</div>
                <input type="number" min={0} value={d.home} onChange={(e) => setDraft(m, { home: Number(e.target.value) })}
                  className="w-full rounded-lg border border-line bg-black/30 py-1 text-center text-lg font-bold text-white" />
                <input type="number" min={0} value={d.away} onChange={(e) => setDraft(m, { away: Number(e.target.value) })}
                  className="w-full rounded-lg border border-line bg-black/30 py-1 text-center text-lg font-bold text-white" />
                <div className="col-span-2 truncate text-sm font-semibold text-white">{m.teamAwayName}</div>
              </div>
              <div className="flex flex-wrap gap-2">
                {m.status === "scheduled" && <Button variant="secondary" onClick={() => action(m.id, "start")}>Demarrer</Button>}
                {m.status === "live" && <Button variant="secondary" onClick={() => action(m.id, "pause")}>Pause</Button>}
                {m.status === "paused" && <Button variant="secondary" onClick={() => action(m.id, "resume")}>Reprendre</Button>}
                <Button variant="secondary" onClick={() => saveScore(m)}>Enregistrer</Button>
                <Button onClick={() => validate(m)}>Valider</Button>
              </div>
            </Card>
          );
        })}
      </div>

      <h3 className="mb-3 font-bold text-white">Historique</h3>
      {finished.length === 0 ? <EmptyState title="Pas encore de match termine" /> : (
        <Card className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-white/40">
                <th className="px-4 py-3">Rencontre</th><th className="px-4 py-3">Score final</th><th className="px-4 py-3">Terrain</th>
              </tr>
            </thead>
            <tbody>
              {finished.map((m) => (
                <tr key={m.id} className="border-b border-line/50">
                  <td className="px-4 py-3 text-white">{m.teamHomeName} <span className="text-white/30">vs</span> {m.teamAwayName}</td>
                  <td className="px-4 py-3 font-bold text-accent">{m.homeScore} : {m.awayScore}</td>
                  <td className="px-4 py-3 text-white/50">{m.fieldName}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
}
