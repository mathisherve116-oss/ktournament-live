"use client";
import { useEffect, useState } from "react";
import { PageHeader, Card, Field, Select, Input, Button, Badge, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api-client";

interface Category { id: string; name: string; teamsCount: number; }
interface GroupTeam { teamId: string; name: string; clubName: string | null; }
interface Group { id: string; name: string; status: string; teams: GroupTeam[]; }

export default function GroupsPage({ params }: { params: { id: string } }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [groupsCount, setGroupsCount] = useState(2);
  const [groups, setGroups] = useState<Group[] | null>(null);
  const [busy, setBusy] = useState(false);

  async function loadCategories() {
    const res = await apiGet<Category[]>(`/api/tournaments/${params.id}/categories`);
    setCategories(res.data || []);
    if (!categoryId && res.data?.[0]) setCategoryId(res.data[0].id);
  }
  async function loadGroups(catId: string) {
    if (!catId) return;
    const res = await apiGet<Group[]>(`/api/tournaments/${params.id}/groups?categoryId=${catId}`);
    setGroups(res.data || []);
  }

  useEffect(() => { loadCategories(); }, [params.id]);
  useEffect(() => { if (categoryId) loadGroups(categoryId); }, [categoryId]);

  async function generate() {
    setBusy(true);
    await apiPost("/api/groups/auto-generate", { categoryId, groupsCount });
    await loadGroups(categoryId);
    setBusy(false);
  }

  async function validate(groupId: string) {
    await apiPost(`/api/groups/${groupId}/validate`);
    await loadGroups(categoryId);
  }

  return (
    <div>
      <PageHeader eyebrow="Ecrans 08 · 09" title="Poules" subtitle="Repartition automatique et equilibree des equipes en poules." />
      <Card className="mb-6 max-w-2xl">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 sm:items-end">
          <Field label="Categorie">
            <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name} ({c.teamsCount} equipes)</option>)}
            </Select>
          </Field>
          <Field label="Nombre de poules">
            <Input type="number" min={1} value={groupsCount} onChange={(e) => setGroupsCount(Number(e.target.value))} />
          </Field>
          <Button onClick={generate} disabled={busy || !categoryId}>{busy ? "Generation..." : "Generer les poules"}</Button>
        </div>
        <p className="mt-3 text-xs text-white/40">La generation remplace les poules existantes de cette categorie et redistribue les equipes aleatoirement de facon equilibree.</p>
      </Card>

      {groups === null && <div className="flex justify-center py-10"><Spinner /></div>}
      {groups && groups.length === 0 && <EmptyState title="Aucune poule generee" subtitle="Choisissez un nombre de poules et cliquez sur generer." />}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {groups?.map((g) => (
          <Card key={g.id}>
            <div className="mb-3 flex items-center justify-between">
              <h4 className="font-bold text-white">{g.name}</h4>
              <Badge status={g.status}>{g.status === "validated" ? "Validee" : "Brouillon"}</Badge>
            </div>
            <ul className="space-y-1 text-sm text-white/70">
              {g.teams.map((t) => <li key={t.teamId}>• {t.name}</li>)}
            </ul>
            {g.status !== "validated" && (
              <Button variant="secondary" className="mt-3 w-full" onClick={() => validate(g.id)}>Valider la poule</Button>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
