"use client";
import { useEffect, useState } from "react";
import { PageHeader, Card, Field, Select, Input, Button, Badge, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api-client";

interface Category { id: string; name: string; }
interface FieldRow { id: string; name: string; }
interface MatchDetail {
  id: string; teamHomeName: string; teamAwayName: string; fieldName: string | null; scheduledAt: string;
  status: string; homeScore: number | null; awayScore: number | null; round: string | null;
}

const STATUS_LABELS: Record<string, string> = { scheduled: "Planifie", live: "En direct", paused: "Pause", finished: "Termine", cancelled: "Annule" };

export default function MatchesPage({ params }: { params: { id: string } }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [fields, setFields] = useState<FieldRow[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [matches, setMatches] = useState<MatchDetail[] | null>(null);
  const [startTime, setStartTime] = useState("");
  const [slotMinutes, setSlotMinutes] = useState(15);
  const [busy, setBusy] = useState(false);

  async function loadRefs() {
    const [catRes, fieldRes] = await Promise.all([
      apiGet<Category[]>(`/api/tournaments/${params.id}/categories`),
      apiGet<FieldRow[]>(`/api/tournaments/${params.id}/fields`),
    ]);
    setCategories(catRes.data || []);
    setFields(fieldRes.data || []);
    if (!categoryId && catRes.data?.[0]) setCategoryId(catRes.data[0].id);
    setStartTime(new Date().toISOString().slice(0, 16));
  }
  async function loadMatches() {
    const res = await apiGet<MatchDetail[]>(`/api/tournaments/${params.id}/matches`);
    setMatches(res.data || []);
  }

  useEffect(() => { loadRefs(); loadMatches(); }, [params.id]);

  async function generate() {
    if (!categoryId || !startTime) return;
    setBusy(true);
    await apiPost("/api/matches/generate", {
      categoryId,
      startTime: new Date(startTime).toISOString(),
      slotMinutes,
      fieldIds: fields.map((f) => f.id),
    });
    await loadMatches();
    setBusy(false);
  }

  return (
    <div>
      <PageHeader eyebrow="Ecrans 11 · 12" title="Matchs & planning" subtitle="Generation automatique du calendrier a partir des poules validees." />
      <Card className="mb-6 max-w-3xl">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-4 sm:items-end">
          <Field label="Categorie">
            <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Debut">
            <Input type="datetime-local" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
          </Field>
          <Field label="Duree creneau (min)">
            <Input type="number" min={5} value={slotMinutes} onChange={(e) => setSlotMinutes(Number(e.target.value))} />
          </Field>
          <Button onClick={generate} disabled={busy}>{busy ? "Generation..." : "Generer les matchs"}</Button>
        </div>
        <p className="mt-3 text-xs text-white/40">Les matchs sont repartis automatiquement sur les {fields.length} terrain(s) disponibles.</p>
      </Card>

      {matches === null && <div className="flex justify-center py-10"><Spinner /></div>}
      {matches && matches.length === 0 && <EmptyState title="Aucun match planifie" />}

      {matches && matches.length > 0 && (
        <Card className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-white/40">
                <th className="px-4 py-3">Heure</th>
                <th className="px-4 py-3">Terrain</th>
                <th className="px-4 py-3">Rencontre</th>
                <th className="px-4 py-3">Score</th>
                <th className="px-4 py-3">Statut</th>
              </tr>
            </thead>
            <tbody>
              {matches.map((m) => (
                <tr key={m.id} className="border-b border-line/50">
                  <td className="px-4 py-3 text-white/70">{new Date(m.scheduledAt).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</td>
                  <td className="px-4 py-3 text-white/70">{m.fieldName || "—"}{m.round ? ` · ${m.round}` : ""}</td>
                  <td className="px-4 py-3 font-medium text-white">{m.teamHomeName} <span className="text-white/30">vs</span> {m.teamAwayName}</td>
                  <td className="px-4 py-3 text-white/70">{m.homeScore ?? "-"} : {m.awayScore ?? "-"}</td>
                  <td className="px-4 py-3"><Badge status={m.status}>{STATUS_LABELS[m.status] || m.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
}
