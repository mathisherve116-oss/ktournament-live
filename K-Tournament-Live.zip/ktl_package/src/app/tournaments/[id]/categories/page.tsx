"use client";
import { useEffect, useState } from "react";
import { PageHeader, Card, Field, Input, Button, Badge, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost, apiDelete } from "@/lib/api-client";

interface Category { id: string; name: string; ageGroup: string | null; teamsCount: number; status: string; }

export default function CategoriesPage({ params }: { params: { id: string } }) {
  const [categories, setCategories] = useState<Category[] | null>(null);
  const [form, setForm] = useState({ name: "", ageGroup: "" });
  const [submitting, setSubmitting] = useState(false);

  async function load() {
    const res = await apiGet<Category[]>(`/api/tournaments/${params.id}/categories`);
    setCategories(res.data || []);
  }
  useEffect(() => { load(); }, [params.id]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name) return;
    setSubmitting(true);
    await apiPost(`/api/tournaments/${params.id}/categories`, form);
    setForm({ name: "", ageGroup: "" });
    await load();
    setSubmitting(false);
  }

  async function remove(id: string) {
    await apiDelete(`/api/categories/${id}`);
    await load();
  }

  return (
    <div>
      <PageHeader eyebrow="Ecran 05" title="Categories" subtitle="Une categorie regroupe les equipes d'une meme tranche d'age ou niveau." />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <h3 className="mb-3 font-bold text-white">Ajouter une categorie</h3>
          <form onSubmit={onSubmit} className="space-y-3">
            <Field label="Nom"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="U11 Garcons" /></Field>
            <Field label="Tranche d'age"><Input value={form.ageGroup} onChange={(e) => setForm({ ...form, ageGroup: e.target.value })} placeholder="U11" /></Field>
            <Button type="submit" disabled={submitting} className="w-full">Ajouter</Button>
          </form>
        </Card>
        <div className="lg:col-span-2">
          {categories === null && <div className="flex justify-center py-10"><Spinner /></div>}
          {categories && categories.length === 0 && <EmptyState title="Aucune categorie" subtitle="Ajoutez votre premiere categorie a gauche." />}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {categories?.map((c) => (
              <Card key={c.id}>
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-white">{c.name}</h4>
                    <p className="text-xs text-white/40">{c.ageGroup}</p>
                  </div>
                  <Badge status={c.status}>{c.teamsCount} equipes</Badge>
                </div>
                <button onClick={() => remove(c.id)} className="mt-3 text-xs text-danger/80 hover:text-danger">Supprimer</button>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
