"use client";
import { useEffect, useState } from "react";
import { PageHeader, Card, Field as FieldWrap, Input, Button, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost, apiDelete } from "@/lib/api-client";

interface FieldRow { id: string; name: string; type: string; color: string; location: string | null; active: number; }

export default function FieldsPage({ params }: { params: { id: string } }) {
  const [fields, setFields] = useState<FieldRow[] | null>(null);
  const [form, setForm] = useState({ name: "", location: "" });
  const [submitting, setSubmitting] = useState(false);

  async function load() {
    const res = await apiGet<FieldRow[]>(`/api/tournaments/${params.id}/fields`);
    setFields(res.data || []);
  }
  useEffect(() => { load(); }, [params.id]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name) return;
    setSubmitting(true);
    await apiPost(`/api/tournaments/${params.id}/fields`, form);
    setForm({ name: "", location: "" });
    await load();
    setSubmitting(false);
  }

  async function remove(id: string) {
    await apiDelete(`/api/fields/${id}`);
    await load();
  }

  return (
    <div>
      <PageHeader eyebrow="Ecran 06" title="Terrains" subtitle="Les terrains disponibles servent a planifier les matchs et affecter les creneaux." />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <h3 className="mb-3 font-bold text-white">Ajouter un terrain</h3>
          <form onSubmit={onSubmit} className="space-y-3">
            <FieldWrap label="Nom"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Terrain A" /></FieldWrap>
            <FieldWrap label="Emplacement"><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Cote nord" /></FieldWrap>
            <Button type="submit" disabled={submitting} className="w-full">Ajouter</Button>
          </form>
        </Card>
        <div className="lg:col-span-2">
          {fields === null && <div className="flex justify-center py-10"><Spinner /></div>}
          {fields && fields.length === 0 && <EmptyState title="Aucun terrain" />}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {fields?.map((f) => (
              <Card key={f.id}>
                <div className="flex items-center gap-2">
                  <span className="h-3 w-3 rounded-full" style={{ backgroundColor: f.color }} />
                  <h4 className="font-bold text-white">{f.name}</h4>
                </div>
                <p className="mt-1 text-xs text-white/40">{f.location}</p>
                <button onClick={() => remove(f.id)} className="mt-3 text-xs text-danger/80 hover:text-danger">Supprimer</button>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
