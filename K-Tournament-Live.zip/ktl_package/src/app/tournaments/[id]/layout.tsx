"use client";
import { RequireAuth } from "@/components/RequireAuth";
import { BackofficeShell } from "@/components/BackofficeShell";
import { TournamentTabs } from "@/components/TournamentTabs";

export default function TournamentLayout({ children, params }: { children: React.ReactNode; params: { id: string } }) {
  return (
    <RequireAuth>
      <BackofficeShell>
        <TournamentTabs tournamentId={params.id} />
        <div className="kt-fade-in">{children}</div>
      </BackofficeShell>
    </RequireAuth>
  );
}
