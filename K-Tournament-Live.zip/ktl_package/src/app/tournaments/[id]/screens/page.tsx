"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { PageHeader, Card, Field, Select, Input, Button, Badge, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api-client";

interface Screen { id: string; name: string; type: string; location: string | null; status: string; }

export default function ScreensPage({ params }: { params: { id: string } }) {
  const [screens, setScreens] = useState<Screen[] | null>(null);
  const [form, setForm] = useState({ name: "", type: "tv", location: "" });

  async function load() {
    const res = await apiGet<Screen[]>(`/api/tournaments/${params.id}/screens`);
    setScreens(res.data || []);
  }
  useEffect(() => { load(); }, [params.id]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name) return;
    await apiPost(`/api/tournaments/${params.id}/screens`, form);
    setForm({ name: "", type: "tv", location: "" });
    await load();
  }

  return (
    <div>
      <PageHeader eyebrow="Ecrans 22-24" title="Ecrans connectes" subtitle="Ajoutez vos TV et videoprojecteurs, puis pilotez-les depuis K'Remote." />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <h3 className="mb-3 font-bold text-white">Ajouter un ecran</h3>
          <form onSubmit={onSubmit} className="space-y-3">
            <Field label="Nom"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ecran club-house" /></Field>
            <Field label="Type">
              <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                <option value="tv">TV</option>
                <option value="projector">Videoprojecteur</option>
                <option value="tablet">Tablette</option>
              </Select>
            </Field>
            <Field label="Emplacement"><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></Field>
            <Button type="submit" className="w-full">Ajouter</Button>
          </form>
        </Card>
        <div className="lg:col-span-2">
          {screens === null && <div className="flex justify-center py-10"><Spinner /></div>}
          {screens && screens.length === 0 && <EmptyState title="Aucun ecran configure" />}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {screens?.map((s) => (
              <Card key={s.id}>
                <div className="mb-1 flex items-start justify-between">
                  <h4 className="font-bold text-white">{s.name}</h4>
                  <Badge status={s.status}>{s.status === "offline" ? "Hors ligne" : s.status === "online" ? "En ligne" : "Projection"}</Badge>
                </div>
                <p className="text-xs text-white/40">{s.location}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Link href={`/screen/${s.id}`} target="_blank"><Button variant="secondary">Ouvrir l'ecran</Button></Link>
                  <Link href={`/remote/${params.id}/${s.id}`}><Button>Piloter</Button></Link>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
