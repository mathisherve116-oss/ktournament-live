"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { PageHeader, Card, Badge, Button, Spinner } from "@/components/ui";
import { apiGet, apiPost, apiPut } from "@/lib/api-client";

interface Summary {
  tournament: { id: string; name: string; status: string; location: string | null; startDate: string; endDate: string };
  stats: { categories: number; teams: number; matches: number; matchesFinished: number; matchesLive: number; sponsors: number; screens: number; screensOnline: number };
  publicLink: { slug: string; status: string } | null;
}

const STATUS_LABELS: Record<string, string> = { draft: "Brouillon", scheduled: "Planifie", live: "En direct", finished: "Termine", archived: "Archive" };

export default function SummaryPage({ params }: { params: { id: string } }) {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const res = await apiGet<Summary>(`/api/tournaments/${params.id}/summary`);
    setSummary(res.data);
  }

  useEffect(() => { load(); }, [params.id]);

  async function toggleStart() {
    setBusy(true);
    const isLive = summary?.tournament.status === "live";
    await apiPost(`/api/tournaments/${params.id}/${isLive ? "finish" : "start"}`);
    await load();
    setBusy(false);
  }

  async function togglePublicLink() {
    if (!summary?.publicLink) return;
    setBusy(true);
    const next = summary.publicLink.status === "active" ? "disabled" : "active";
    await apiPut(`/api/tournaments/${params.id}/public-link`, { status: next });
    await load();
    setBusy(false);
  }

  if (!summary) return <div className="flex justify-center py-16"><Spinner /></div>;

  const publicUrl = summary.publicLink ? `/t/${summary.publicLink.slug}` : null;

  return (
    <div>
      <PageHeader
        eyebrow="Ecran 18"
        title={summary.tournament.name}
        subtitle={summary.tournament.location || ""}
        actions={
          <Button onClick={toggleStart} disabled={busy} variant={summary.tournament.status === "live" ? "danger" : "primary"}>
            {summary.tournament.status === "live" ? "Cloturer le tournoi" : "Lancer le tournoi"}
          </Button>
        }
      />

      <div className="mb-6">
        <Badge status={summary.tournament.status}>{STATUS_LABELS[summary.tournament.status] || summary.tournament.status}</Badge>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard label="Categories" value={summary.stats.categories} />
        <StatCard label="Equipes" value={summary.stats.teams} />
        <StatCard label="Matchs" value={summary.stats.matches} sub={`${summary.stats.matchesFinished} termines · ${summary.stats.matchesLive} en direct`} />
        <StatCard label="Sponsors" value={summary.stats.sponsors} />
        <StatCard label="Ecrans" value={summary.stats.screens} sub={`${summary.stats.screensOnline} en ligne`} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <h3 className="mb-3 font-bold text-white">Page publique QR</h3>
          {publicUrl ? (
            <div className="space-y-3 text-sm">
              <p className="text-white/60">Partagez ce lien avec les parents, coachs et joueurs — aucune inscription requise.</p>
              <div className="flex items-center gap-2 rounded-lg border border-line bg-black/30 px-3 py-2 font-mono text-xs text-accent">
                {publicUrl}
              </div>
              <div className="flex gap-2">
                <Link href={publicUrl} target="_blank"><Button variant="secondary">Ouvrir la page publique</Button></Link>
                <Button variant={summary.publicLink?.status === "active" ? "danger" : "primary"} onClick={togglePublicLink} disabled={busy}>
                  {summary.publicLink?.status === "active" ? "Desactiver le lien" : "Reactiver le lien"}
                </Button>
              </div>
            </div>
          ) : <p className="text-sm text-white/50">Lien public non disponible.</p>}
        </Card>

        <Card>
          <h3 className="mb-3 font-bold text-white">Pilotage rapide</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <Link href={`/tournaments/${params.id}/scores`}><Button variant="secondary" className="w-full">Saisir un score</Button></Link>
            <Link href={`/tournaments/${params.id}/screens`}><Button variant="secondary" className="w-full">Gerer les ecrans</Button></Link>
            <Link href={`/remote/${params.id}`}><Button variant="secondary" className="w-full">Ouvrir K'Remote</Button></Link>
            <Link href={`/tournaments/${params.id}/sponsors`}><Button variant="secondary" className="w-full">Gerer les sponsors</Button></Link>
          </div>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ label, value, sub }: { label: string; value: number; sub?: string }) {
  return (
    <Card className="text-center">
      <div className="text-3xl font-black text-white">{value}</div>
      <div className="mt-1 text-xs uppercase tracking-wide text-white/40">{label}</div>
      {sub && <div className="mt-1 text-xs text-white/30">{sub}</div>}
    </Card>
  );
}
