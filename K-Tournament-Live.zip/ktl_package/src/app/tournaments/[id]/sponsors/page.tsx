"use client";
import { useEffect, useState } from "react";
import { PageHeader, Card, Field, Select, Input, Button, Badge, EmptyState, Spinner } from "@/components/ui";
import { apiGet, apiPost, apiPut, apiDelete } from "@/lib/api-client";

interface Sponsor { id: string; name: string; level: string; status: string; slogan: string | null; durationSeconds: number; }

const LEVEL_LABELS: Record<string, string> = { platinum: "Platinum", gold: "Gold", silver: "Silver", partner: "Partenaire" };

export default function SponsorsPage({ params }: { params: { id: string } }) {
  const [sponsors, setSponsors] = useState<Sponsor[] | null>(null);
  const [form, setForm] = useState({ name: "", level: "partner", slogan: "", durationSeconds: 8 });

  async function load() {
    const res = await apiGet<Sponsor[]>(`/api/tournaments/${params.id}/sponsors`);
    setSponsors(res.data || []);
  }
  useEffect(() => { load(); }, [params.id]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name) return;
    await apiPost(`/api/tournaments/${params.id}/sponsors`, form);
    setForm({ name: "", level: "partner", slogan: "", durationSeconds: 8 });
    await load();
  }

  async function toggle(s: Sponsor) {
    await apiPut(`/api/sponsors/${s.id}`, { status: s.status === "active" ? "inactive" : "active" });
    await load();
  }

  async function remove(id: string) {
    await apiDelete(`/api/sponsors/${id}`);
    await load();
  }

  return (
    <div>
      <PageHeader eyebrow="Ecrans 12 · 24" title="Sponsors" subtitle="Gerez la boucle de diffusion sponsors affichee sur K'Screen et la page QR publique." />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <h3 className="mb-3 font-bold text-white">Ajouter un sponsor</h3>
          <form onSubmit={onSubmit} className="space-y-3">
            <Field label="Nom"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="Niveau">
              <Select value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })}>
                <option value="platinum">Platinum</option>
                <option value="gold">Gold</option>
                <option value="silver">Silver</option>
                <option value="partner">Partenaire</option>
              </Select>
            </Field>
            <Field label="Slogan"><Input value={form.slogan} onChange={(e) => setForm({ ...form, slogan: e.target.value })} /></Field>
            <Field label="Duree affichage (s)"><Input type="number" min={3} value={form.durationSeconds} onChange={(e) => setForm({ ...form, durationSeconds: Number(e.target.value) })} /></Field>
            <Button type="submit" className="w-full">Ajouter</Button>
          </form>
        </Card>
        <div className="lg:col-span-2">
          {sponsors === null && <div className="flex justify-center py-10"><Spinner /></div>}
          {sponsors && sponsors.length === 0 && <EmptyState title="Aucun sponsor configure" />}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {sponsors?.map((s) => (
              <Card key={s.id}>
                <div className="mb-1 flex items-start justify-between">
                  <h4 className="font-bold text-white">{s.name}</h4>
                  <Badge status={s.status}>{LEVEL_LABELS[s.level]}</Badge>
                </div>
                <p className="text-xs text-white/40">{s.slogan}</p>
                <p className="mt-1 text-xs text-white/30">{s.durationSeconds}s par passage</p>
                <div className="mt-3 flex gap-2">
                  <Button variant="secondary" onClick={() => toggle(s)}>{s.status === "active" ? "Desactiver" : "Activer"}</Button>
                  <Button variant="danger" onClick={() => remove(s.id)}>Supprimer</Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
