"use client";
import { useEffect, useState } from "react";
import { PageHeader, Card, Field, Input, Button, Spinner } from "@/components/ui";
import { apiGet, apiPut } from "@/lib/api-client";

interface Settings {
  matchDuration: number; winPoints: number; drawPoints: number; lossPoints: number; teamsQualified: number;
}

export default function SettingsPage({ params }: { params: { id: string } }) {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    apiGet<Settings>(`/api/tournaments/${params.id}/settings`).then((res) => setSettings(res.data));
  }, [params.id]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    await apiPut(`/api/tournaments/${params.id}/settings`, settings);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  if (!settings) return <div className="flex justify-center py-16"><Spinner /></div>;

  return (
    <div>
      <PageHeader eyebrow="Ecran 04" title="Parametres du tournoi" subtitle="Bareme de points, duree des matchs et regles de qualification." />
      <Card className="max-w-2xl">
        <form onSubmit={save} className="space-y-4">
          <Field label="Duree d'un match (minutes)">
            <Input type="number" min={1} value={settings.matchDuration} onChange={(e) => setSettings({ ...settings, matchDuration: Number(e.target.value) })} />
          </Field>
          <div className="grid grid-cols-3 gap-4">
            <Field label="Points victoire">
              <Input type="number" value={settings.winPoints} onChange={(e) => setSettings({ ...settings, winPoints: Number(e.target.value) })} />
            </Field>
            <Field label="Points nul">
              <Input type="number" value={settings.drawPoints} onChange={(e) => setSettings({ ...settings, drawPoints: Number(e.target.value) })} />
            </Field>
            <Field label="Points defaite">
              <Input type="number" value={settings.lossPoints} onChange={(e) => setSettings({ ...settings, lossPoints: Number(e.target.value) })} />
            </Field>
          </div>
          <Field label="Equipes qualifiees par poule">
            <Input type="number" min={1} value={settings.teamsQualified} onChange={(e) => setSettings({ ...settings, teamsQualified: Number(e.target.value) })} />
          </Field>
          <div className="rounded-lg border border-line bg-black/20 p-3 text-xs text-white/50">
            Ordre de departage applique automatiquement : points, difference de buts, buts marques, confrontation directe.
          </div>
          <Button type="submit" disabled={saving}>{saving ? "Enregistrement..." : saved ? "Enregistre ✓" : "Enregistrer"}</Button>
        </form>
      </Card>
    </div>
  );
}
