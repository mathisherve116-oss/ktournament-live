"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { RequireAuth } from "@/components/RequireAuth";
import { PageHeader, Card, Badge, EmptyState, Spinner } from "@/components/ui";
import { apiGet } from "@/lib/api-client";

interface Screen { id: string; name: string; type: string; location: string | null; status: string; }

function Content({ tournamentId }: { tournamentId: string }) {
  const [screens, setScreens] = useState<Screen[] | null>(null);

  useEffect(() => {
    apiGet<Screen[]>(`/api/remote/screens?tournamentId=${tournamentId}`).then((res) => setScreens(res.data || []));
  }, [tournamentId]);

  return (
    <div className="mx-auto min-h-screen max-w-md px-4 py-6">
      <PageHeader eyebrow="Ecran 19 · K'Remote" title="Choisir un ecran" subtitle="Selectionnez l'ecran a piloter depuis votre telephone." />
      {screens === null && <div className="flex justify-center py-10"><Spinner /></div>}
      {screens && screens.length === 0 && <EmptyState title="Aucun ecran configure" subtitle="Ajoutez un ecran depuis le back-office." />}
      <div className="space-y-3">
        {screens?.map((s) => (
          <Link key={s.id} href={`/remote/${tournamentId}/${s.id}`}>
            <Card className="flex items-center justify-between active:scale-[0.98]">
              <div>
                <div className="font-bold text-white">{s.name}</div>
                <div className="text-xs text-white/40">{s.location}</div>
              </div>
              <Badge status={s.status}>{s.status === "offline" ? "Hors ligne" : s.status === "online" ? "En ligne" : "Projection"}</Badge>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default function RemoteSelectScreenPage({ params }: { params: { tournamentId: string } }) {
  return (
    <RequireAuth>
      <Content tournamentId={params.tournamentId} />
    </RequireAuth>
  );
}
