"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { RequireAuth } from "@/components/RequireAuth";
import { PageHeader, Card, Button, Badge, Spinner } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api-client";
import { useRealtimeRoom } from "@/lib/useSocket";

interface Screen { id: string; name: string; status: string; }
interface Session { activeContentType: string; status: string; updatedAt: string; }

const CONTENT_LABELS: Record<string, string> = {
  home: "Accueil tournoi", live: "Match en direct", planning: "Planning", rankings: "Classements",
  sponsors: "Sponsors", qr: "QR public", message: "Message", idle: "En veille",
};

function Content({ tournamentId, screenId }: { tournamentId: string; screenId: string }) {
  const [screen, setScreen] = useState<Screen | null>(null);
  const [session, setSession] = useState<Session | null>(null);

  const load = useCallback(async () => {
    const res = await apiGet<{ screen: Screen; session: Session }>(`/api/screens/${screenId}/session`);
    if (res.data) { setScreen(res.data.screen); setSession(res.data.session); }
  }, [screenId]);

  useEffect(() => { load(); }, [load]);
  useRealtimeRoom(`tournament:${tournamentId}`, { "screen.contentChanged": load, "screen.connected": load, "screen.disconnected": load });

  async function command(cmd: string) {
    await apiPost("/api/remote/command", { screenId, command: cmd });
    await load();
  }
  async function stop() {
    await apiPost("/api/remote/stop", { screenId });
    await load();
  }

  if (!screen) return <div className="flex min-h-screen items-center justify-center"><Spinner /></div>;

  return (
    <div className="mx-auto min-h-screen max-w-md px-4 py-6">
      <PageHeader eyebrow="Ecran 21 · K'Remote" title="Telecommande live" subtitle={screen.name} />

      <Card className="mb-6 text-center">
        <div className="text-xs uppercase tracking-wide text-white/40">Contenu actuellement projete</div>
        <div className="mt-2 text-2xl font-black text-accent">{CONTENT_LABELS[session?.activeContentType || "idle"]}</div>
        <div className="mt-2"><Badge status={screen.status}>{screen.status === "projecting" ? "En projection" : screen.status}</Badge></div>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Button variant="secondary" onClick={() => command("refresh")}>Rafraichir</Button>
        <Button variant="secondary" onClick={() => command("next-match")}>Match suivant</Button>
        <Button variant="secondary" onClick={() => command("sponsor-loop-start")}>Lancer sponsors</Button>
        <Button variant="secondary" onClick={() => command("sponsor-loop-stop")}>Stopper sponsors</Button>
      </div>

      <div className="mt-6 space-y-2">
        <Link href={`/remote/${tournamentId}/${screenId}`}><Button variant="secondary" className="w-full">Changer de contenu</Button></Link>
        <Button variant="danger" className="w-full" onClick={stop}>Stopper la projection</Button>
      </div>
    </div>
  );
}

export default function RemoteLivePage({ params }: { params: { tournamentId: string; screenId: string } }) {
  return (
    <RequireAuth>
      <Content tournamentId={params.tournamentId} screenId={params.screenId} />
    </RequireAuth>
  );
}
