"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { RequireAuth } from "@/components/RequireAuth";
import { PageHeader, Card, Button, Field, Select, Spinner } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api-client";

interface Category { id: string; name: string; }
interface Group { id: string; name: string; }

const CONTENT_TYPES = [
  { value: "home", label: "Accueil tournoi" },
  { value: "live", label: "Match en direct" },
  { value: "planning", label: "Planning" },
  { value: "rankings", label: "Classements" },
  { value: "sponsors", label: "Sponsors" },
  { value: "qr", label: "QR code public" },
  { value: "message", label: "Message personnalise" },
];

function Content({ tournamentId, screenId }: { tournamentId: string; screenId: string }) {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [groupId, setGroupId] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    apiGet<Category[]>(`/api/tournaments/${tournamentId}/categories`).then((res) => {
      setCategories(res.data || []);
      if (res.data?.[0]) setCategoryId(res.data[0].id);
    });
  }, [tournamentId]);

  useEffect(() => {
    if (!categoryId) return;
    apiGet<Group[]>(`/api/tournaments/${tournamentId}/groups?categoryId=${categoryId}`).then((res) => {
      setGroups(res.data || []);
      if (res.data?.[0]) setGroupId(res.data[0].id);
    });
  }, [categoryId, tournamentId]);

  async function project(contentType: string) {
    setBusy(true);
    const payload: Record<string, unknown> = { tournamentId, categoryId, groupId };
    if (contentType === "message") payload.message = message;
    await apiPost("/api/remote/project-content", { screenId, contentType, payload });
    setBusy(false);
    router.push(`/remote/${tournamentId}/${screenId}/live`);
  }

  return (
    <div className="mx-auto min-h-screen max-w-md px-4 py-6">
      <PageHeader eyebrow="Ecran 20 · K'Remote" title="Choisir le contenu" subtitle="Ce qui sera projete immediatement sur l'ecran." />

      {categories.length > 0 && (
        <Card className="mb-4">
          <div className="space-y-3">
            <Field label="Categorie">
              <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </Select>
            </Field>
            {groups.length > 0 && (
              <Field label="Poule (classements)">
                <Select value={groupId} onChange={(e) => setGroupId(e.target.value)}>
                  {groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
                </Select>
              </Field>
            )}
          </div>
        </Card>
      )}

      <div className="space-y-2">
        {CONTENT_TYPES.map((ct) => (
          <Button key={ct.value} variant="secondary" disabled={busy} onClick={() => project(ct.value)} className="w-full justify-between">
            <span>{ct.label}</span>
            <span className="text-white/30">→</span>
          </Button>
        ))}
      </div>

      <Card className="mt-4">
        <Field label="Message personnalise">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={2}
            className="w-full rounded-lg border border-line bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-accent"
            placeholder="Ex: Merci a tous les benevoles !"
          />
        </Field>
        <Button className="mt-2 w-full" disabled={busy || !message} onClick={() => project("message")}>Projeter le message</Button>
      </Card>

      {busy && <div className="mt-4 flex justify-center"><Spinner /></div>}
    </div>
  );
}

export default function RemoteSelectContentPage({ params }: { params: { tournamentId: string; screenId: string } }) {
  return (
    <RequireAuth>
      <Content tournamentId={params.tournamentId} screenId={params.screenId} />
    </RequireAuth>
  );
}
