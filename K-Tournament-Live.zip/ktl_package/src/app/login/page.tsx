"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { Button, Card, Input, Label } from "@/components/ui";

export default function LoginPage() {
  const { user, loading, login } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("admin@kdosports.fr");
  const [password, setPassword] = useState("Kdosports2026!");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!loading && user) router.replace("/dashboard");
  }, [loading, user, router]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    const res = await login(email, password);
    setSubmitting(false);
    if (res.ok) router.replace("/dashboard");
    else setError(res.message || "Connexion impossible");
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-md kt-fade-in">
        <div className="mb-8 text-center">
          <div className="mb-2 text-3xl font-black tracking-tight text-white">
            K'<span className="text-accent">TOURNAMENT</span> LIVE
          </div>
          <p className="text-sm text-white/50">Back-office organisateur</p>
        </div>
        <Card>
          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <Label>Email</Label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div>
              <Label>Mot de passe</Label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            {error && <p className="text-sm text-danger">{error}</p>}
            <Button type="submit" disabled={submitting} className="w-full">
              {submitting ? "Connexion..." : "Se connecter"}
            </Button>
          </form>
        </Card>
        <div className="mt-6 rounded-xl border border-line bg-panel/50 p-4 text-xs text-white/40">
          <p className="mb-2 font-semibold text-white/60">Comptes de demonstration</p>
          <p>admin@kdosports.fr — administrateur</p>
          <p>club@as-lumiere.fr — responsable club</p>
          <p>tournoi@as-lumiere.fr — responsable tournoi</p>
          <p>score@as-lumiere.fr — benevole score</p>
          <p>ecran@as-lumiere.fr — responsable ecran</p>
          <p className="mt-2">Mot de passe pour tous : <span className="text-white/60">Kdosports2026!</span></p>
        </div>
      </div>
    </div>
  );
}
