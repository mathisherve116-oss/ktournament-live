"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { apiGet } from "@/lib/api-client";
import { useRealtimeRoom } from "@/lib/useSocket";

interface Sponsor { id: string; name: string; slogan: string | null; level: string; durationSeconds: number; }
interface Tournament { id: string; name: string; location: string | null; city: string | null; status: string }
interface Category { id: string; name: string }
interface MatchRow { id: string; teamHomeName: string; teamAwayName: string; fieldName: string | null; status: string; homeScore: number | null; awayScore: number | null; scheduledAt: string; }
interface Ranking { teamId: string; teamName: string; played: number; wins: number; draws: number; losses: number; diff: number; points: number; rank: number; }

interface ScreenContent {
  contentType: string;
  tournament: Tournament;
  sponsors: Sponsor[];
  publicSlug?: string;
  categories?: Category[];
  matches?: MatchRow[];
  rankings?: Ranking[];
  message?: string;
}

const LEVEL_COLOR: Record<string, string> = { platinum: "#E5E7EB", gold: "#F5C542", silver: "#C7CCD1", partner: "#7DD3A0" };

export default function ScreenPage({ params }: { params: { screenId: string } }) {
  const [content, setContent] = useState<ScreenContent | null>(null);
  const [sponsorIdx, setSponsorIdx] = useState(0);
  const [clock, setClock] = useState(new Date());
  const [tournamentId, setTournamentId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await apiGet<ScreenContent>(`/api/screens/${params.screenId}/content`);
    if (res.data) {
      setContent(res.data);
      setTournamentId(res.data.tournament.id);
    }
  }, [params.screenId]);

  useEffect(() => { load(); const i = setInterval(load, 4000); return () => clearInterval(i); }, [load]);
  useRealtimeRoom(`screen:${params.screenId}`, { "screen.contentChanged": load });
  useRealtimeRoom(tournamentId ? `tournament:${tournamentId}` : null, { "score.updated": load, "match.started": load, "match.finished": load, "ranking.updated": load, "screen.contentChanged": load });

  useEffect(() => { const i = setInterval(() => setClock(new Date()), 1000); return () => clearInterval(i); }, []);
  useEffect(() => {
    if (!content?.sponsors.length) return;
    const dur = (content.sponsors[sponsorIdx % content.sponsors.length]?.durationSeconds || 8) * 1000;
    const t = setTimeout(() => setSponsorIdx((i) => i + 1), dur);
    return () => clearTimeout(t);
  }, [content, sponsorIdx]);

  if (!content) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink text-white/40">
        Connexion a l'ecran...
      </div>
    );
  }

  const sponsor = content.sponsors.length ? content.sponsors[sponsorIdx % content.sponsors.length] : null;

  return (
    <div className="flex min-h-screen flex-col bg-ink text-white">
      <header className="flex items-center justify-between border-b border-line px-10 py-5">
        <div className="text-2xl font-black tracking-tight">
          K'<span className="text-accent">TOURNAMENT</span> LIVE
        </div>
        <div className="text-right">
          <div className="text-lg font-bold">{content.tournament.name}</div>
          <div className="text-sm text-white/40">{content.tournament.location}</div>
        </div>
        <div className="font-mono text-2xl text-accent">{clock.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</div>
      </header>

      <main className="flex-1 px-10 py-8">
        {content.contentType === "home" && <HomeView content={content} />}
        {(content.contentType === "live" || content.contentType === "planning") && <MatchesView matches={content.matches || []} live={content.contentType === "live"} />}
        {content.contentType === "rankings" && <RankingsView rankings={content.rankings || []} />}
        {content.contentType === "sponsors" && <SponsorSpotlightView sponsors={content.sponsors} />}
        {content.contentType === "qr" && <QrView slug={content.publicSlug} />}
        {content.contentType === "message" && <MessageView message={content.message || ""} />}
        {content.contentType === "idle" && <IdleView content={content} />}
      </main>

      <footer className="flex h-24 items-center justify-between border-t border-line bg-panel px-10">
        {sponsor ? (
          <div key={sponsor.id} className="kt-fade-in flex items-center gap-4">
            <span className="h-3 w-3 rounded-full" style={{ backgroundColor: LEVEL_COLOR[sponsor.level] }} />
            <span className="text-xl font-bold">{sponsor.name}</span>
            {sponsor.slogan && <span className="text-white/40">— {sponsor.slogan}</span>}
          </div>
        ) : <span className="text-white/30">K'dosports — SportTech pour clubs amateurs</span>}
        {content.publicSlug && <span className="font-mono text-sm text-white/30">Suivez en direct : /t/{content.publicSlug}</span>}
      </footer>
    </div>
  );
}

function HomeView({ content }: { content: ScreenContent }) {
  return (
    <div className="flex h-full flex-col items-center justify-center text-center">
      <p className="mb-3 text-sm uppercase tracking-[0.3em] text-accent">Bienvenue sur</p>
      <h1 className="mb-4 text-6xl font-black">{content.tournament.name}</h1>
      <p className="text-xl text-white/50">{content.tournament.location} {content.tournament.city ? `— ${content.tournament.city}` : ""}</p>
      <div className="mt-10 flex gap-3">
        {content.categories?.map((c) => (
          <span key={c.id} className="rounded-full border border-line bg-panel px-5 py-2 text-lg font-semibold">{c.name}</span>
        ))}
      </div>
    </div>
  );
}

function MatchesView({ matches, live }: { matches: MatchRow[]; live: boolean }) {
  const filtered = live ? matches.filter((m) => m.status === "live" || m.status === "paused") : matches;
  const list = filtered.length ? filtered : matches.slice(0, 8);
  return (
    <div className="mx-auto max-w-5xl space-y-3">
      {list.map((m) => (
        <div key={m.id} className={`flex items-center justify-between rounded-2xl border px-8 py-5 ${m.status === "live" ? "border-accent bg-accent/10" : "border-line bg-panel"}`}>
          <div className="w-2/5 truncate text-right text-2xl font-bold">{m.teamHomeName}</div>
          <div className="flex items-center gap-4 px-6">
            <span className="text-4xl font-black text-white">{m.homeScore ?? "-"}</span>
            <span className="text-2xl text-white/30">:</span>
            <span className="text-4xl font-black text-white">{m.awayScore ?? "-"}</span>
          </div>
          <div className="w-2/5 truncate text-2xl font-bold">{m.teamAwayName}</div>
        </div>
      ))}
    </div>
  );
}

function RankingsView({ rankings }: { rankings: Ranking[] }) {
  return (
    <div className="mx-auto max-w-4xl overflow-hidden rounded-2xl border border-line">
      <table className="w-full text-xl">
        <thead>
          <tr className="bg-panel text-left text-sm uppercase tracking-wide text-white/40">
            <th className="px-6 py-4">#</th><th className="px-6 py-4">Equipe</th><th className="px-4 py-4">J</th>
            <th className="px-4 py-4">Diff</th><th className="px-4 py-4">Pts</th>
          </tr>
        </thead>
        <tbody>
          {rankings.map((r) => (
            <tr key={r.teamId} className="border-t border-line">
              <td className="px-6 py-4 font-black text-accent">{r.rank}</td>
              <td className="px-6 py-4 font-bold">{r.teamName}</td>
              <td className="px-4 py-4 text-white/60">{r.played}</td>
              <td className="px-4 py-4 text-white/60">{r.diff > 0 ? `+${r.diff}` : r.diff}</td>
              <td className="px-4 py-4 font-black">{r.points}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SponsorSpotlightView({ sponsors }: { sponsors: Sponsor[] }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-6">
      {sponsors.map((s) => (
        <div key={s.id} className="text-4xl font-black">{s.name}</div>
      ))}
    </div>
  );
}

function QrView({ slug }: { slug?: string }) {
  const url = slug ? `${typeof window !== "undefined" ? window.location.origin : ""}/t/${slug}` : "";
  return (
    <div className="flex h-full flex-col items-center justify-center gap-6 text-center">
      <p className="text-3xl font-bold">Suivez le tournoi en direct</p>
      {url && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          alt="QR code public"
          className="rounded-2xl border-4 border-white bg-white p-4"
          src={`https://api.qrserver.com/v1/create-qr-code/?size=320x320&data=${encodeURIComponent(url)}`}
        />
      )}
      <p className="font-mono text-xl text-accent">{url}</p>
    </div>
  );
}

function MessageView({ message }: { message: string }) {
  return (
    <div className="flex h-full items-center justify-center text-center text-5xl font-black">
      {message}
    </div>
  );
}

function IdleView({ content }: { content: ScreenContent }) {
  return <HomeView content={content} />;
}
