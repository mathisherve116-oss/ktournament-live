"use client";
import { useEffect, useState } from "react";
import { PublicNav } from "@/components/PublicNav";
import { PublicUnavailable } from "@/components/PublicUnavailable";
import { Spinner } from "@/components/ui";
import { apiGet } from "@/lib/api-client";

interface Sponsor { id: string; name: string; slogan: string | null; level: string; linkUrl: string | null; }

const LEVEL_LABELS: Record<string, string> = { platinum: "Partenaire Platinum", gold: "Partenaire Gold", silver: "Partenaire Silver", partner: "Partenaire" };

export default function PublicSponsorsPage({ params }: { params: { slug: string } }) {
  const [sponsors, setSponsors] = useState<Sponsor[] | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    apiGet<Sponsor[]>(`/api/public/${params.slug}/sponsors`).then((res) => {
      if (res.data) setSponsors(res.data); else setNotFound(true);
    });
  }, [params.slug]);

  if (notFound) return <PublicUnavailable />;
  if (!sponsors) return <div className="flex min-h-screen items-center justify-center bg-ink"><Spinner /></div>;

  return (
    <div className="min-h-screen bg-ink px-4 pb-24 pt-8 text-white">
      <h1 className="mb-4 text-xl font-black">Nos sponsors</h1>
      <div className="space-y-3">
        {sponsors.map((s) => (
          <a key={s.id} href={s.linkUrl || undefined} target={s.linkUrl ? "_blank" : undefined} rel="noreferrer"
            className="block rounded-xl border border-line bg-panel p-4">
            <div className="text-xs font-semibold uppercase tracking-wide text-accent">{LEVEL_LABELS[s.level]}</div>
            <div className="mt-1 text-lg font-bold">{s.name}</div>
            {s.slogan && <div className="text-sm text-white/50">{s.slogan}</div>}
          </a>
        ))}
      </div>
      <PublicNav slug={params.slug} />
    </div>
  );
}
