"use client";
import { useEffect, useState } from "react";
import { PublicNav } from "@/components/PublicNav";
import { PublicUnavailable } from "@/components/PublicUnavailable";
import { Spinner } from "@/components/ui";
import { apiGet } from "@/lib/api-client";

interface Ranking { teamId: string; teamName: string; played: number; diff: number; points: number; rank: number; }
interface GroupRanking { group: { id: string; name: string }; rankings: Ranking[]; }

export default function PublicRankingsPage({ params }: { params: { slug: string } }) {
  const [groups, setGroups] = useState<GroupRanking[] | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    const load = () => apiGet<GroupRanking[]>(`/api/public/${params.slug}/rankings`).then((res) => {
      if (res.data) setGroups(res.data); else setNotFound(true);
    });
    load();
    const i = setInterval(load, 8000);
    return () => clearInterval(i);
  }, [params.slug]);

  if (notFound) return <PublicUnavailable />;
  if (!groups) return <div className="flex min-h-screen items-center justify-center bg-ink"><Spinner /></div>;

  return (
    <div className="min-h-screen bg-ink px-4 pb-24 pt-8 text-white">
      <h1 className="mb-4 text-xl font-black">Classements</h1>
      <div className="space-y-6">
        {groups.map((g) => (
          <div key={g.group.id} className="overflow-hidden rounded-xl border border-line">
            <div className="bg-panel px-4 py-2 font-bold">{g.group.name}</div>
            <table className="w-full text-sm">
              <tbody>
                {g.rankings.map((r) => (
                  <tr key={r.teamId} className="border-t border-line/50">
                    <td className="px-3 py-2 font-bold text-accent">{r.rank}</td>
                    <td className="px-3 py-2 font-medium">{r.teamName}</td>
                    <td className="px-3 py-2 text-right text-white/50">{r.diff > 0 ? `+${r.diff}` : r.diff}</td>
                    <td className="px-3 py-2 text-right font-bold">{r.points} pts</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>
      <PublicNav slug={params.slug} />
    </div>
  );
}
