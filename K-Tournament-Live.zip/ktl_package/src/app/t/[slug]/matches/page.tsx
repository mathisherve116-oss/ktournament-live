"use client";
import { useEffect, useState } from "react";
import { PublicNav } from "@/components/PublicNav";
import { PublicUnavailable } from "@/components/PublicUnavailable";
import { Spinner, Badge } from "@/components/ui";
import { apiGet } from "@/lib/api-client";

interface MatchRow {
  id: string; teamHomeName: string; teamAwayName: string; fieldName: string | null; scheduledAt: string;
  status: string; homeScore: number | null; awayScore: number | null;
}

const STATUS_LABELS: Record<string, string> = { scheduled: "A venir", live: "En direct", paused: "Pause", finished: "Termine", cancelled: "Annule" };

export default function PublicMatchesPage({ params }: { params: { slug: string } }) {
  const [matches, setMatches] = useState<MatchRow[] | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    const load = () => apiGet<MatchRow[]>(`/api/public/${params.slug}/matches`).then((res) => {
      if (res.data) setMatches(res.data); else setNotFound(true);
    });
    load();
    const i = setInterval(load, 6000);
    return () => clearInterval(i);
  }, [params.slug]);

  if (notFound) return <PublicUnavailable />;
  if (!matches) return <div className="flex min-h-screen items-center justify-center bg-ink"><Spinner /></div>;

  return (
    <div className="min-h-screen bg-ink px-4 pb-24 pt-8 text-white">
      <h1 className="mb-4 text-xl font-black">Matchs</h1>
      <div className="space-y-3">
        {matches.map((m) => (
          <div key={m.id} className={`rounded-xl border p-4 ${m.status === "live" ? "border-accent bg-accent/10" : "border-line bg-panel"}`}>
            <div className="mb-2 flex items-center justify-between text-xs text-white/40">
              <span>{m.fieldName}</span>
              <Badge status={m.status}>{STATUS_LABELS[m.status]}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="w-2/5 truncate font-semibold">{m.teamHomeName}</span>
              <span className="font-black text-accent">{m.homeScore ?? "-"} : {m.awayScore ?? "-"}</span>
              <span className="w-2/5 truncate text-right font-semibold">{m.teamAwayName}</span>
            </div>
          </div>
        ))}
      </div>
      <PublicNav slug={params.slug} />
    </div>
  );
}
