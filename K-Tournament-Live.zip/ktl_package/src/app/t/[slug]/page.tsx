"use client";
import { useEffect, useState } from "react";
import { PublicNav } from "@/components/PublicNav";
import { Spinner, Badge } from "@/components/ui";
import { apiGet } from "@/lib/api-client";
import { PublicUnavailable } from "@/components/PublicUnavailable";

interface Tournament { id: string; name: string; location: string | null; city: string | null; status: string; startDate: string; endDate: string; }
interface Category { id: string; name: string; ageGroup: string | null; }
interface FieldRow { id: string; name: string; }
interface PublicData { tournament: Tournament; categories: Category[]; fields: FieldRow[]; }

const STATUS_LABELS: Record<string, string> = { draft: "A venir", scheduled: "Planifie", live: "En direct", finished: "Termine", archived: "Termine" };

export default function PublicHomePage({ params }: { params: { slug: string } }) {
  const [data, setData] = useState<PublicData | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    apiGet<PublicData>(`/api/public/${params.slug}`).then((res) => {
      if (res.data) setData(res.data); else setNotFound(true);
    });
  }, [params.slug]);

  if (notFound) return <PublicUnavailable />;
  if (!data) return <div className="flex min-h-screen items-center justify-center bg-ink"><Spinner /></div>;

  return (
    <div className="min-h-screen bg-ink pb-20 text-white">
      <div className="px-5 pt-8 text-center">
        <div className="mb-1 text-xs font-bold uppercase tracking-[0.3em] text-accent">Suivi en direct</div>
        <h1 className="text-2xl font-black">{data.tournament.name}</h1>
        <p className="mt-1 text-sm text-white/50">{data.tournament.location}{data.tournament.city ? `, ${data.tournament.city}` : ""}</p>
        <div className="mt-3"><Badge status={data.tournament.status}>{STATUS_LABELS[data.tournament.status]}</Badge></div>
      </div>

      <div className="mt-8 px-5">
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-white/40">Categories</h2>
        <div className="grid grid-cols-2 gap-3">
          {data.categories.map((c) => (
            <div key={c.id} className="rounded-xl border border-line bg-panel p-4 text-center">
              <div className="font-bold">{c.name}</div>
              <div className="text-xs text-white/40">{c.ageGroup}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-8 px-5">
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-white/40">Terrains</h2>
        <div className="flex flex-wrap gap-2">
          {data.fields.map((f) => (
            <span key={f.id} className="rounded-full border border-line bg-panel px-3 py-1.5 text-sm">{f.name}</span>
          ))}
        </div>
      </div>

      <PublicNav slug={params.slug} />
    </div>
  );
}
