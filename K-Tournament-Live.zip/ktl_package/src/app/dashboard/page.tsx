"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { RequireAuth } from "@/components/RequireAuth";
import { BackofficeShell } from "@/components/BackofficeShell";
import { Badge, Button, Card, EmptyState, PageHeader, Spinner } from "@/components/ui";
import { apiGet } from "@/lib/api-client";

interface Tournament {
  id: string; name: string; startDate: string; endDate: string; location: string | null; city: string | null; status: string;
}

const STATUS_LABELS: Record<string, string> = { draft: "Brouillon", scheduled: "Planifie", live: "En direct", finished: "Termine", archived: "Archive" };

function DashboardContent() {
  const [tournaments, setTournaments] = useState<Tournament[] | null>(null);

  useEffect(() => {
    apiGet<Tournament[]>("/api/tournaments").then((res) => setTournaments(res.data || []));
  }, []);

  return (
    <BackofficeShell>
      <PageHeader
        eyebrow="Back-office"
        title="Mes tournois"
        subtitle="Creez, configurez et pilotez vos tournois amateurs de bout en bout."
        actions={<Link href="/tournaments/new"><Button>+ Nouveau tournoi</Button></Link>}
      />

      {tournaments === null && (
        <div className="flex justify-center py-16"><Spinner /></div>
      )}

      {tournaments && tournaments.length === 0 && (
        <EmptyState title="Aucun tournoi pour le moment" subtitle="Lancez votre premier tournoi en quelques minutes." />
      )}

      {tournaments && tournaments.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {tournaments.map((t) => (
            <Link key={t.id} href={`/tournaments/${t.id}/summary`}>
              <Card className="kt-fade-in h-full transition hover:border-accent/50">
                <div className="mb-3 flex items-start justify-between">
                  <h3 className="text-lg font-bold text-white">{t.name}</h3>
                  <Badge status={t.status}>{STATUS_LABELS[t.status] || t.status}</Badge>
                </div>
                <p className="text-sm text-white/50">{t.location || t.city || "Lieu non defini"}</p>
                <p className="mt-3 text-xs text-white/40">
                  {new Date(t.startDate).toLocaleDateString("fr-FR")} — {new Date(t.endDate).toLocaleDateString("fr-FR")}
                </p>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </BackofficeShell>
  );
}

export default function DashboardPage() {
  return (
    <RequireAuth>
      <DashboardContent />
    </RequireAuth>
  );
}
