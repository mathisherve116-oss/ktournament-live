import { hashPassword } from "../src/lib/auth";
import {
  createClub, createUser, createTournament, createCategory, createField, createTeam,
  autoGenerateGroups, listGroups, generateMatchesForCategory, createSponsor, createScreen,
  submitScore, validateScore, recalculateGroupRanking, listMatches, getPublicLinkByTournament,
} from "../src/lib/repo";
import { db } from "../src/lib/db";

async function main() {
  console.log("Nettoyage de la base de demonstration...");
  const tables = [
    "audit_logs", "public_links", "screen_contents", "sponsor_rotations", "sponsors",
    "final_phases", "screen_sessions", "screens", "rankings", "scores", "match_events",
    "matches", "group_teams", "groups_", "teams", "categories", "fields",
    "tournament_settings", "tournaments", "users", "clubs",
  ];
  for (const t of tables) db.exec(`DELETE FROM ${t}`);

  console.log("Creation du club de demonstration...");
  const club = createClub({ name: "AS Lumiere FC", slug: "as-lumiere-fc", city: "Lyon", country: "France", contactEmail: "contact@as-lumiere.fr" });

  const password = await hashPassword("Kdosports2026!");
  const admin = createUser({ clubId: club.id, firstName: "Sacha", lastName: "Admin", email: "admin@kdosports.fr", passwordHash: password, role: "admin" });
  createUser({ clubId: club.id, firstName: "Marc", lastName: "Dubois", email: "club@as-lumiere.fr", passwordHash: password, role: "club_manager" });
  createUser({ clubId: club.id, firstName: "Julie", lastName: "Martin", email: "tournoi@as-lumiere.fr", passwordHash: password, role: "tournament_manager" });
  createUser({ clubId: club.id, firstName: "Karim", lastName: "Benali", email: "score@as-lumiere.fr", passwordHash: password, role: "score_volunteer" });
  createUser({ clubId: club.id, firstName: "Lea", lastName: "Perrin", email: "ecran@as-lumiere.fr", passwordHash: password, role: "screen_manager" });

  console.log("Creation du tournoi de demonstration...");
  const tournament = createTournament({
    clubId: club.id,
    name: "K'Tournament Ete U11 - AS Lumiere",
    startDate: new Date().toISOString(),
    endDate: new Date(Date.now() + 86400000).toISOString(),
    location: "Complexe sportif Jean Moulin",
    city: "Lyon",
    mainCategory: "U11",
  });

  const category = createCategory({ tournamentId: tournament.id, name: "U11 Garcons", ageGroup: "U11" });

  const fieldNames = ["Terrain A", "Terrain B", "Terrain C"];
  const fields = fieldNames.map((name, i) => createField({ tournamentId: tournament.id, name, color: ["#00D97E", "#3B82F6", "#F59E0B"][i] }));

  const teamNames = [
    "FC Lyon Nord", "ASPTT Villeurbanne", "Olympique Bron", "US Vaulx-en-Velin",
    "AS Lumiere FC", "Racing Club Meyzieu", "FC Decines", "Stade Rilleux",
    "Etoile Caluire", "Sporting Venissieux", "FC Saint-Priest", "Vaulx Athletic",
  ];
  const teams = teamNames.map((name) => createTeam({ tournamentId: tournament.id, categoryId: category.id, name, clubName: name }));

  console.log("Repartition en poules...");
  autoGenerateGroups(category.id, 3);
  const groups = listGroups(tournament.id, category.id);

  console.log("Generation des matchs...");
  generateMatchesForCategory(category.id, {
    startTime: new Date().toISOString(),
    slotMinutes: 15,
    fieldIds: fields.map((f) => f.id),
  });

  console.log("Simulation de quelques scores...");
  const matches = listMatches(tournament.id, { categoryId: category.id });
  matches.slice(0, Math.floor(matches.length / 2)).forEach((m) => {
    const homeScore = Math.floor(Math.random() * 5);
    const awayScore = Math.floor(Math.random() * 5);
    submitScore(m.id, homeScore, awayScore, admin.id);
    validateScore(m.id, admin.id);
  });
  groups.forEach((g) => recalculateGroupRanking(g.id));

  console.log("Creation des sponsors...");
  createSponsor({ tournamentId: tournament.id, name: "K'dosports", level: "platinum", slogan: "Equipementier officiel du tournoi", durationSeconds: 10 });
  createSponsor({ tournamentId: tournament.id, name: "Boulangerie du Stade", level: "gold", slogan: "La buvette gourmande", durationSeconds: 8 });
  createSponsor({ tournamentId: tournament.id, name: "Auto Sport Lyon", level: "silver", slogan: "Partenaire mobilite", durationSeconds: 8 });
  createSponsor({ tournamentId: tournament.id, name: "Club des supporters", level: "partner", slogan: "Merci de votre soutien", durationSeconds: 6 });

  console.log("Creation des ecrans...");
  createScreen({ tournamentId: tournament.id, name: "Ecran Club-house", type: "tv", location: "Buvette" });
  createScreen({ tournamentId: tournament.id, name: "Videoprojecteur Terrain A", type: "projector", location: "Terrain A" });

  const link = getPublicLinkByTournament(tournament.id);

  console.log("\n--- Seed termine ---");
  console.log(`Club: ${club.name}`);
  console.log(`Tournoi: ${tournament.name} (id: ${tournament.id})`);
  console.log(`Lien public QR: /t/${link?.slug}`);
  console.log("\nComptes de demonstration (mot de passe: Kdosports2026!):");
  console.log(" - admin@kdosports.fr           (admin)");
  console.log(" - club@as-lumiere.fr           (responsable club)");
  console.log(" - tournoi@as-lumiere.fr        (responsable tournoi)");
  console.log(" - score@as-lumiere.fr          (benevole score)");
  console.log(" - ecran@as-lumiere.fr          (responsable ecran)");
}

main().then(() => process.exit(0)).catch((err) => {
  console.error(err);
  process.exit(1);
});
